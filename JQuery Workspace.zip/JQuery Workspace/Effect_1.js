$(document).ready(function(){
	$("#btn").on("click",function(){
		//$("div").fadeToggle();
		//$("div").fadeOut();
		//$("div").fadeTo("slow",0.2);
		//$("div").slideUp(10000);
		//$("div").slideToggle();
		
		$("div").animate({height:'150px',width:'200px'},"slow");
	});
	$("#btn1").click(function(){
		$("div").stop();		
	});
});