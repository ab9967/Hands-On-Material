import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Ex1 {

	public static void main(String args[])
	{
		String s = "123_1234_123";
		
		Pattern pat1 = Pattern.compile("^[0-9]{3}_[0-9]{4}_[0-9]{3}$");
		//Pattern pat1 = Pattern.compile("^[1|2|3]{3}_[1|2|3|4]{4}_[1|2|3]{3}$");
		//Pattern pat1 = Pattern.compile("^\\d\\d\\d_\\d\\d\\d\\d_\\d\\d\\d$");
		Matcher mat1 = pat1.matcher(s);
		
		System.out.println(mat1.matches());
		
		/*String s = "123_1234 123";
		
		Pattern pat1 = Pattern.compile("^[0-9]{3}[_|\\s][0-9]{4}[_|\\s][0-9]{3}$");
		//Pattern pat1 = Pattern.compile("^[1|2|3]{3}_[1|2|3|4]{4}_[1|2|3]{3}$");
		Matcher mat1 = pat1.matcher(s);
		
		System.out.println(mat1.matches());*/
		
		/*String s = "suydbgj";
		
		Pattern pat1 = Pattern.compile("![//s]+$");
		Matcher mat1 = pat1.matcher(s);
				
		System.out.println(mat1.matches());*/
	}
	
}
