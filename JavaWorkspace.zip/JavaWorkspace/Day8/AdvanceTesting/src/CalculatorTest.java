import junit.framework.TestCase;


public class CalculatorTest extends TestCase {

	protected static void setUpBeforeClass() throws Exception {
	}

	protected static void tearDownAfterClass() throws Exception {
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testAdd() {
		fail("Not yet implemented");
	}

	public void testSubtract() {
		fail("Not yet implemented");
	}

	public void testMultiply() {
		fail("Not yet implemented");
	}

}
