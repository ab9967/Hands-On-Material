package com.cg.assignment.Q_8p1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.Reader;
import java.io.Writer;

public class FileOperations {

	public static void main(String[] args) {
	
		FileInputStream in = null;
		FileOutputStream out = null;
		try
		{
			in = new FileInputStream("D:\\temp.txt");
			int c,i=0;
			//displaying data from temp.txt
			while((c = in.read()) != -1)
			{
				System.out.print((char)c);
				i++;
			}
			
			in = new FileInputStream("D:\\temp.txt");
			char revContent[] = new char[i+1];
			i=0;
			//buffering file content in an char array
			while((c = in.read()) != -1)
			{
				revContent[i] = (char)c;
				i++;
			}
			System.out.println();
			System.out.println();
									
			out = new FileOutputStream("D:\\temp1.txt");
			//storing file content in a text file from array in reverse order
			for(int j=revContent.length-1; j>=0;j--)
			{
				System.out.print(revContent[j]);
				out.write((byte)revContent[j]);
			}
			
			System.out.println("From output file");
			System.out.println();
			System.out.println();
			in = new FileInputStream("D:\\temp1.txt");
			i=0;
			//displaying content from different file where reversed content is stored
			while((c = in.read()) != -1)
			{
				System.out.print((char)c);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e);
		}
		
	}

}
