package com.cg.assignment.eisPl;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.cg.assignment.Q_8p3.FileOperations;
import com.cg.assignment.eisBean.Employee;
import com.cg.assignment.eisService.Service;

public class TestMain {

	public static void main(String args[])
	{
		Employee e = new Employee("101","Scott","Manager",50000);
		System.out.println(e);
		
		Service s = new Service();
		//String iScheme = null;
		//iScheme = ;
			
		e.setInsurance_scheme(s.calcScheme(e.salary,e.designation));
		
		System.out.println("Employee Details :");
		System.out.println("------------------------");
		System.out.println("ID : "+e.id);
		System.out.println("Name : "+e.name);
		System.out.println("Designation : "+e.designation);
		System.out.println("Salary : "+e.salary);
		System.out.println("Insurance Scheme : "+e.insurance_scheme);
		
		FileOperations.writeToFile(e);
		
		FileOperations.readFromFile();
	}	
}
