package com.cg.assignment.Q_8p2;

import java.io.File;
import java.util.Scanner;

public class FileOperations2 {

	public static void main(String[] args){

		//creating file reference
		File temp = new File("D:\\JavaWorkspace\\Day6\\Assignment8\\src\\com\\cg\\assignment\\Q_8p2\\Numbers.txt");
		char tempArr[] = null;
		try 
		{
			//generating scanner instance for reading file
			Scanner sc = new Scanner(temp);
			
			if(sc.hasNextLine())
			{
				int flag = 0;
				String tempStr = sc.next();
				tempArr = tempStr.toCharArray();
				int length = tempStr.length();
				
				System.out.println("Even numbers from File Numbers.txt");
				String[] staging = tempStr.split(",");
				for(int j=0;j<staging.length;j++)
					System.out.println(staging[j]);
				
				System.out.println("Even numbers from File Numbers.txt");
				System.out.println("-------------------------------------");
				for(int i=0;i<staging.length;i++)
				{
					int stage1 = Integer.valueOf(staging[i]).intValue();
					if(stage1%2 == 0)
						System.out.println(stage1);
				}
				/*for(int i =0;i<length;i++)
				{
					if(tempArr[i] != ',')
					{
						staging += tempArr[i];
						Integer tempInt = Integer.valueOf(staging);
						int stage1 = tempInt.intValue();
						if((stage1)%2 == 0)
						{
							System.out.println(Integer.parseInt(staging));
						}
					}
					if(tempArr[i] == ',')
					{
						staging = null;
					}
				}*/
			}
			else
			{
				System.out.println("File empty aborting program");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e);
		}
	}

}
