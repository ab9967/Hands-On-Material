package com.cg.assignment.Q_8p3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.cg.assignment.eisBean.Employee;

public class FileOperations {

	private static int charCount = 0;
	
	public static boolean writeToFile(Employee e)
	{
		FileOutputStream out = null;
		String empData = "";
		try {
			out = new FileOutputStream("D:\\JavaWorkspace\\Day6\\Assignment8\\src\\com\\cg\\assignment\\Q_8p3\\EmployeeData.txt");
			empData = e.id+"-"+e.name+"-"+e.designation+"-"+e.salary+"-"+e.insurance_scheme;
			char[] tempArr = empData.toCharArray();
			int length = tempArr.length;
			charCount = length;
			for(int i=0;i<length;i++)
			{
				out.write((byte)tempArr[i]);
			}
					
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//storing employee details in a text file
		catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		 
		//out.write((byte)revContent[j]);
		return true;
	}
	
	public static boolean readFromFile()
	{
		FileInputStream in = null;
		try {
			in = new FileInputStream("D:\\JavaWorkspace\\Day6\\Assignment8\\src\\com\\cg\\assignment\\Q_8p3\\EmployeeData.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		char dataStage1[] = new char[charCount];
		int i=0,c;
		//buffering file content in an char array
		try {
			while((c = in.read()) != -1)
			{
				dataStage1[i] = (char)c;
				System.out.print((char)c);
				i++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String dataStage2 = dataStage1.toString();
		
		String[] staging = dataStage2.split("-");
		
		for(i=0;i<staging.length; i++)
		{
			System.out.println(staging[i]);
		}
		
		return false;
	}
	
}
