package com.cg.assignment.eisException;

public class LowSalaryException extends Exception 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long sal;
	
	public LowSalaryException(long sal)
	{
		this.sal = sal;
	}

	@Override
	public String toString() {
		return "LowSalaryException : " + sal + " is very low salary for any emmployee of this organisation !";
	}
}
