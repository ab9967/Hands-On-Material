package com.cg.ma.Exception;

public class MobileException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1877716604237334375L;

	public MobileException(String msg)
	{
		
	}
}
