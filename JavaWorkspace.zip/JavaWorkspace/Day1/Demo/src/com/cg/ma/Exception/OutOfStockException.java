package com.cg.ma.Exception;

public class OutOfStockException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int purchaseQty,stock;
	public OutOfStockException(int purchaseQty, int stock) {
		super();
		this.purchaseQty = purchaseQty;
		this.stock = stock;
	}
	@Override
	public String toString() {
		return "OutOfStockException \nStock available : "+stock+" | Purchasing Stock : "+purchaseQty;
	}
	
	
	
}
