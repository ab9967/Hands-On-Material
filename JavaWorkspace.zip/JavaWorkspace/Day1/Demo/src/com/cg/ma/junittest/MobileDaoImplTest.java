package com.cg.ma.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Customer;

public class MobileDaoImplTest {

	IMobileDao iMobile;
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		iMobile = new MobileDaoImpl();
		
	}

	@After
	public void tearDown() throws Exception {
		iMobile = null;
	}

	@Test
	public void testShowAll() {
		try {
			assertNotNull(iMobile.showAllMobiles());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void testSearchByRange() {
		try {
			//next line tests whether the mentioned method returns list or null
			//if null value is returned the test case will fail
			assertNotNull(iMobile.searchByRange(20000,60000));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/*@Test
	public void insertPurchaseDetails() {
		try {
			Customer c = new Customer("16-05-2019","King","xyz@gmail.com","9865443223");
			next line tests whether the mentioned method returns true  or false 
			since in implementation the return type is boolean
			//here if insertPurchaseDetials returns false the test will fail
			// i.e. insertion is failed.
			assertTrue(iMobile.insertPurchaseDetails(c,"Samsung Galaxy IV",1));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
}
