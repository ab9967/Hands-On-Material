package ArrayOperations;

import java.util.ArrayList;
import java.util.Collections;

public class StringArrayList {
	
	public static void main(String[] args)
	{
		ArrayList<String> aList = new ArrayList<String>();
		
		aList.add("Milk");
		aList.add("Butter");
		aList.add("Cheese");
		aList.add("Notebook");
		
		System.out.println("List of products ");
		System.out.println("------------------");
		for(Object i : aList)
		{
			System.out.println(i);
		}
		
		System.out.println();
		System.out.println("After Sorting");
		Collections.sort(aList);
		System.out.println("List of products ");
		System.out.println("------------------");
		for(Object i : aList)
		{
			System.out.println(i);
		}
	}	
}