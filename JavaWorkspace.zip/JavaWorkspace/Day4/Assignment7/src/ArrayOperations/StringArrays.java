package ArrayOperations;

import java.util.Arrays;

public class StringArrays {

	static String[] product = new String[]{"Milk","Bread","Ink","Notebook"};
	
	public static void main(String args[])
	{
		System.out.println("Before Sorting");
		for(String i : product)
			System.out.println(i);
		
		Arrays.sort(product);
		
		System.out.println("After Sorting");
		for(String i : product)
			System.out.println(i);
	}
	
}
