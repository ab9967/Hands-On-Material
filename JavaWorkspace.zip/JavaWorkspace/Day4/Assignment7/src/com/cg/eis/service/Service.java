package com.cg.eis.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.eis.bean.Employee;

interface EmployeeServices
{
	String calcScheme(long sal, String desig);
}

public class Service implements EmployeeServices
{
	public HashMap<String,Employee> list = new HashMap<String,Employee>();
	
	public String calcScheme(long sal, String desig)
	{
		if((sal>5000 && sal<20000)&& desig.equals("System Associate"))
		{
			return "Scheme C";
		}
		else if((sal>=20000 && sal<40000)&& desig.equals("Programmer"))
		{
			return "Scheme B";
		}
		else if((sal>=40000)&& desig.equals("Manager"))
		{
			return "Scheme A";
		}
		else if((sal<5000)&& desig.equals("Clerk"))
		{
			return "No Scheme";
		}
		return "Faulty Change";
	}

	public void addToList(String name, Employee eObj)
	{
		list.put(name, eObj);
	}
	
	public void removeFromList(String name)
	{
		list.remove(name);
	}
	
	public Employee getDetails(String iScheme)
	{
		//Employee e = list.get(key)
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	public void sortAndDisplay()
	{
		//System.out.println(list.entrySet());
		Set tempSet = list.entrySet();
		Iterator i = tempSet.iterator();
		
		while (i.hasNext()) {
			Map.Entry mapEntry = (Map.Entry) i.next();
			System.out.println(mapEntry.getKey() + ": " + mapEntry.getValue());
			System.out.println();
		}
	}
}
