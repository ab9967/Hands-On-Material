package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class TestMain {

	public static void main(String args[])
	{
		Employee e = new Employee("101","Scott","Manager",45000);
		Employee e2 = new Employee("102","Tiger","Clerk",2000);
		Employee e3 = new Employee("103","King","System Associate",15000);
		Employee e4 = new Employee("104","Smith","Programmer",35000);
		Employee e5 = new Employee("105","John","Programmer",35000);
		System.out.println(e);

		Service s = new Service();
		//String iScheme = null;
		//iScheme = ;
		e.setInsurance_scheme(s.calcScheme(e.salary,e.designation));
		e2.setInsurance_scheme(s.calcScheme(e2.salary,e2.designation));
		e3.setInsurance_scheme(s.calcScheme(e3.salary,e3.designation));
		e4.setInsurance_scheme(s.calcScheme(e4.salary,e4.designation));
		e5.setInsurance_scheme(s.calcScheme(e5.salary,e5.designation));
		
		System.out.println("Employee Details :");
		System.out.println("------------------------");
		System.out.println("ID : "+e.id);
		System.out.println("Name : "+e.name);
		System.out.println("Designation : "+e.designation);
		System.out.println("Salary : "+e.salary);
		System.out.println("Insurance Scheme : "+e.insurance_scheme);
		
		System.out.println();		
		s.addToList("Scott", e);
		s.addToList("Tiger", e2);
		s.addToList("King", e3);
		s.addToList("Smith", e4);
		s.addToList("John", e5);
		s.sortAndDisplay();
		
		s.removeFromList("King");
		s.sortAndDisplay();
	}
	
}
