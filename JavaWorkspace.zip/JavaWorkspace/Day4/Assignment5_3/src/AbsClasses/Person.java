package AbsClasses;
public class Person extends Account
{
	private String name;
	private float age;
	
	private static long accNumSequence = 0;
	
	public Person(String name, float age, double balance) {
		super(++accNumSequence, balance);
		this.name = name;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}

	public  double getBalance() {
		return getBalance();
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", accNum=" + accNum
				+ ", balance=" + balance + "]";
	}

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		balance -= amount;
	}
	
}
