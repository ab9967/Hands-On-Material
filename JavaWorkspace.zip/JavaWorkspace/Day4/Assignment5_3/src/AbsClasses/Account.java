package AbsClasses;

public abstract class Account {
	protected long accNum;
	protected double balance;
	
	public Account(long accNum, double balance) {
		super();
		this.accNum = accNum;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance+ "]";
	}

	public long getAccNum() {
		return accNum;
	}

	public double getBalance() {
		return balance;
	}

	public abstract void withdraw(double amount);
	
}
