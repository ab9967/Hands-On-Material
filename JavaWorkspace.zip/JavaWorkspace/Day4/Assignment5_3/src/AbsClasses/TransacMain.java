package AbsClasses;

public class TransacMain 
{

	public static void main(String[] args) {
		Person smith = new Person("smith",22,5000);
		Person kathy = new Person("Kathy",23,6000);
		
		System.out.println(smith);
		System.out.println(kathy);
		
		System.out.println("After Withdraw");
		
		smith.withdraw(2000);
		kathy.withdraw(4400);
		
		System.out.println(smith);
		System.out.println(kathy);
	}

}
