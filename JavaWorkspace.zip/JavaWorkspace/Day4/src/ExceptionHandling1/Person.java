package ExceptionHandling1;

public class Person {
	public String firstName;
	public String lastName;
	public char gender;

	public Person() {
		super();
	}

	public Person(String firstName, String lastName, char gender)
	{
		super();
		if(firstName.length() == 0 &&lastName.length() == 0)
			try {
				throw new BlankNameException("first nAMe and last nAMe");
			} catch (BlankNameException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			}
		else if(firstName.length() == 0 )
			try {
				throw new BlankNameException("first nAMe");
			} catch (BlankNameException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				}
		else if(lastName.length() == 0 )
			try {
				throw new BlankNameException("last nAMe");
			} catch (BlankNameException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				}
 
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}

	public void setFirstName(String firstName) {
		if(firstName.length() == 0 )
			try {
				throw new BlankNameException("first nAMe");
			} catch (BlankNameException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				}
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		if(lastName.length() == 0 )
			try {
				throw new BlankNameException("last nAMe");
			} catch (BlankNameException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				}
		this.lastName = lastName;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public char getGender() {
		return gender;
	}
}