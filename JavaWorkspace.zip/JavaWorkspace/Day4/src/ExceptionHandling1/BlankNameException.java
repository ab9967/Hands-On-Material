package ExceptionHandling1;

public class BlankNameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String fieldName = null;

	public BlankNameException(String fieldName) {
		super();
		this.fieldName = fieldName;
	}

	public String toString() {
		fieldName = fieldName.toUpperCase();
		return "BlankNameException: "+fieldName+" cannot be blank !";
	}
}
