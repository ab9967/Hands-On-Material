package ExceptionHandling2;

public class AgeException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private float age;
	
	public AgeException(float age) {
		super();
		this.age = age;
	}

	@Override
	public String toString() {
		return "AgeException : person age should be above 15 , "+age+" is not acceptable age !";
	}
	
}
