package ExceptionHandling2;
public class Person 
{
	private String name;
	private float age;
	
	public Person(String name, float age) {
		super();
		if(age <= 15)
		{
			try {
				throw new AgeException(age);
			} catch (AgeException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		}
		this.name = name;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	
	public float getAge() {
		return age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
