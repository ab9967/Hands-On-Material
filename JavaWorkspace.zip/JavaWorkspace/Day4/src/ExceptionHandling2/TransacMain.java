package ExceptionHandling2;

public class TransacMain 
{

	public static void main(String[] args) {
		Person smith = new Person("smith",14);
		Person kathy = new Person("Kathy",23);
		
		System.out.println(smith);
		System.out.println(kathy);
		
		Account smithAcc = new Account(999,2000);
		smithAcc.setAccHolder(smith);
		System.out.println(smithAcc);
		
		Account kathyAcc = new Account(999,3000);
		kathyAcc.setAccHolder(kathy);
		System.out.println(kathyAcc);
		System.out.println();
		
		smithAcc.deposit(2000);
		
		kathyAcc.withdraw(2000);
		
		System.out.println("Smith account balance :"+smithAcc.getBalance());
		System.out.println("Kathy account balance :"+kathyAcc.getBalance());
		System.out.println();
		
		Person king = new Person("King",8);
		System.out.println(king);
		System.out.println();
		
		SavingsAccount kingAcc = new SavingsAccount(999, 10000);
		System.out.println(kingAcc);
		System.out.println();
		
		kingAcc.withdraw(900);
		System.out.println(kingAcc);
		System.out.println();
		
		kingAcc.withdraw(9000);
		System.out.println(kingAcc);
		System.out.println();
		
		Person scott = new Person("Scott",27);
		System.out.println(scott);
		System.out.println();
		
		CurrentAccount scottAcc = new CurrentAccount(999, 100000);
		System.out.println(scottAcc);
		System.out.println();
		
		scottAcc.withdraw(100500);
		System.out.println(scottAcc);
		System.out.println();
		
	}

}
