package com.cg.eis.bean;

public class Employee {

	public String id, name, designation, insurance_scheme;
	public long salary;
	
	public Employee(String id, String name, String designation, long salary) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;

		this.salary = salary;
	}

	public String getInsurance_scheme() {
		return insurance_scheme;
	}

	public void setInsurance_scheme(String insurance_scheme) {
		this.insurance_scheme = insurance_scheme;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", designation="
				+ designation + ", insurance_scheme=" + insurance_scheme
				+ ", salary=" + salary + "]";
	}
	
	
	
}
