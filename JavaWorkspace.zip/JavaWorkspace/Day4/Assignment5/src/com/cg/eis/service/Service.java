package com.cg.eis.service;

interface EmployeeServices
{
	String calcScheme(long sal, String desig);
}

public class Service implements EmployeeServices
{
	public String calcScheme(long sal, String desig)
	{
		if((sal>5000 && sal<20000)&& desig.equals("System Associate"))
		{
			return "Scheme C";
		}
		else if((sal>=20000 && sal<40000)&& desig.equals("Programmer"))
		{
			return "Scheme B";
		}
		else if((sal>=40000)&& desig.equals("Manager"))
		{
			return "Scheme A";
		}
		else if((sal<5000)&& desig.equals("Clerk"))
		{
			return "No Scheme";
		}
		return "Faulty Change";
	}

}
