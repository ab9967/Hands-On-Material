package EvenOdd;

import java.util.ArrayList;

public class EvenThread extends Thread {

	private ArrayList<Integer> list;
	
	public EvenThread(ArrayList EList)
	{
		this.list = EList;
	}
	
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			if(i%2 == 0)
			{
				list.add(i);
				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
