package EvenOdd;

import java.util.ArrayList;

public class TestThread {
	
	public static void main(String args[])
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		EvenThread even = new EvenThread(list);
		OddThread odd = new OddThread(list);
		
		even.start();
		odd.start();
		
		try {
			even.join();
			odd.join();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		System.out.println(list);
	}

}
