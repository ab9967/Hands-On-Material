package EvenOdd;

import java.util.ArrayList;

public class OddThread extends Thread{
	

	private ArrayList<Integer> list;
	
	public OddThread(ArrayList OList)
	{
		this.list = OList;
	}
	
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			if(i%2 != 0)
			{
				list.add(i);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
