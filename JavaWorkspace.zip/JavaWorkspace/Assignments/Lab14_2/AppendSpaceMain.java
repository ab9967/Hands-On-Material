package Lab14_2;

public class AppendSpaceMain {
	public static void main(String[] args) {
		StringBuilder result = new StringBuilder();
		AppendSpace apsp = (input)->{
		for (int i = 0; i < input.length(); i++) {
			   if (i > 0) {
			      result.append(" ");
			    }
			   result.append(input.charAt(i));
			}
		return result.toString();
		};
		String res=apsp.addSpace("Prathamesh");
		System.out.println(res);
	}

}
