package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;
import com.cg.eis.service.StoreToDatabase;

public class TestMain {

	public static void main(String args[])
	{
		Employee e = new Employee("1001","Scott","Manager",50000);
		Employee e1 = new Employee("1002","Tiger","Programmer",30000);
		Employee e2 = new Employee("1003","King","Manager",45000);
				
		Service s = new Service();
		//String iScheme = null;
		//iScheme = ;
			
		e.setInsurance_scheme(s.calcScheme(e.salary,e.designation));
		e1.setInsurance_scheme(s.calcScheme(e1.salary,e1.designation));
		e2.setInsurance_scheme(s.calcScheme(e2.salary,e2.designation));
		
		/*System.out.println("Employee Details :");
		System.out.println("------------------------");
		System.out.println("ID : "+e.id);
		System.out.println("Name : "+e.name);
		System.out.println("Designation : "+e.designation);
		System.out.println("Salary : "+e.salary);
		System.out.println("Insurance Scheme : "+e.insurance_scheme);*/
		
		boolean flag = StoreToDatabase.writeToDB(e);
		if(flag)
			System.out.println(e.name+ "\'s data inserted.");
		
		flag = StoreToDatabase.writeToDB(e1);
		if(flag)
			System.out.println(e1.name+ "\'s data inserted.");
		
		flag = StoreToDatabase.writeToDB(e2);
		if(flag)
			System.out.println(e2.name+ "\'s data inserted.");
		
	}	
}
