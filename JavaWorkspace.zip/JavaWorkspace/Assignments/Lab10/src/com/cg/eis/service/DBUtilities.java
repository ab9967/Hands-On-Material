package com.cg.eis.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtilities {

	static 	Connection conn = null;
	
	public static Properties loadProperty()
	{
		Properties prop = new Properties();
		InputStream in = null;
		
		try {
			in = new FileInputStream("D:\\Module2\\Assignments\\Lab10\\src\\com\\cg\\eis\\service\\oracle.properties");
			prop.load(in);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return prop;
	}	
	public static Connection getConnection()
	{
	
		
		Properties prop = loadProperty();
		String url = prop.getProperty("oracle.url");
		String driver = prop.getProperty("oracle.driver");
		String uname = prop.getProperty("oracle.uname");
		String pwd = prop.getProperty("oracle.pwd");
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, uname, pwd);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
}
