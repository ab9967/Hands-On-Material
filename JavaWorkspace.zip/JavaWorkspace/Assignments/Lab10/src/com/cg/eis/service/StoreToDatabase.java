package com.cg.eis.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.DBUtilities;

public class StoreToDatabase {

	public static boolean writeToDB(Employee e)
	{
		
		Connection con = null;
		PreparedStatement pst = null;
		con = DBUtilities.getConnection();
		if(con != null)
		{
			System.out.println("Connected");
		}
		else
		{
			System.out.println("Not Connected");
			System.exit(0);
		}
		
		String query= "insert into emp_data (empid,ename,designation,salary,ischeme) values (?,?,?,?,?)";
		try {
			pst = con.prepareStatement(query);
			pst.setString(1, e.id);
			pst.setString(2, e.name);
			pst.setString(3, e.designation);
			pst.setLong(4, e.salary);
			pst.setString(5, e.insurance_scheme);
			int count = pst.executeUpdate();
			System.out.println(count+" rows inserted.");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return true;
	}
	
}
