package com.cg.PersonPropsB;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PersonPropertiesB {

	public static void main(String args[])
	{
		FileInputStream in = null;
		FileOutputStream out = null;
		Properties prop = new Properties();
		try {
			out = new FileOutputStream("D:\\Module2\\Assignments\\Lab10\\src\\com\\cg\\PersonProps\\PersonProp.properties");
			
			prop.setProperty("person","Harish");
			prop.setProperty("person2","John");
			prop.setProperty("person3","Scott");
			prop.store(out,"Person information");
			out.close();
			
			in = new FileInputStream("D:\\Module2\\Assignments\\Lab10\\src\\com\\cg\\PersonProps\\PersonProp.properties");
			prop.load(in);
			
			System.out.println("Person Properties:\n");
			String p = prop.getProperty("person");
			System.out.println(p);
			p = prop.getProperty("person2");
			System.out.println(p);
			p = prop.getProperty("person3");
			System.out.println(p);
			
	}catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
}
