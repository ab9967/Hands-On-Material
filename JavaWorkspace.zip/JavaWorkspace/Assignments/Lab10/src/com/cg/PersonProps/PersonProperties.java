package com.cg.PersonProps;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PersonProperties {

	public static void main(String args[])
	{
		FileInputStream in = null;
		FileOutputStream out = null;
		Properties prop = new Properties();
		try {
			out = new FileOutputStream("D:\\Module2\\Assignments\\Lab10\\src\\com\\cg\\PersonProps\\PersonProp.properties");
			
			prop.setProperty("person","Harish");
			prop.setProperty("person2","John");
			prop.setProperty("person3","Scott");
			prop.store(out,"Person information");
			out.close();
			
			in = new FileInputStream("D:\\Module2\\Assignments\\Lab10\\src\\com\\cg\\PersonProps\\PersonProp.properties");
			prop.load(in);
			
			prop.list(System.out);
			
//			System.out.println(prop);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
