package Lab14_4;

import java.util.function.Consumer;

public class PersonMain {
	public static void main(String[] args) {
	
		Person p = new Person("Prathamesh", 56);
		Consumer<Person> p1 = Person::getName;
		p1.accept(p);
		System.out.print((p));
	}

}
