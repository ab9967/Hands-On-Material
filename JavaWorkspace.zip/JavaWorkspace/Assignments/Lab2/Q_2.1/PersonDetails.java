class PersonMain
{
	public static void main(String args[])
	{
		String fname, lname;
		char gender;
		int age = 20;
		float weight = (float)85.55;
		fname = "Divya";
		lname = "Bharathi";
		gender = 'F';
		
		System.out.println("Person Details:");
		System.out.println("--------------------");
		System.out.println("First Name: "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
	}//main Method
}//class