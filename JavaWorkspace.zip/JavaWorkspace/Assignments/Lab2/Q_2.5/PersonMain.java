package NewThree;
import java.util.Scanner;
public class PersonMain {
	/*public void show()
	{
		Person p = new Person();
	}*/
	@SuppressWarnings({ "static-access", "resource" })
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		gender gender = null;
		String phoneNumber;
		
		System.out.println("Enter Gender : ");
		gender = gender.valueOf(sc.next());
		
		Person person = new Person("Aniket","Bhirud",gender);
		
		System.out.println("Enter phone Number : ");
		phoneNumber = sc.next();
		person.setPhoneNumber(phoneNumber);
		
		person.show();
	}
}
