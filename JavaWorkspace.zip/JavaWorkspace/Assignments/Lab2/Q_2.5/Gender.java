package NewThree;

	 
	enum gender
	 {
		 M , F;
	 }
