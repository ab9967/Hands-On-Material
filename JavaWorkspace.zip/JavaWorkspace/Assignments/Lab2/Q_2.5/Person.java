package NewThree;

public class Person 
{
	String firstName;
	String lastName;
	gender g;
	String phoneNumber;
	public Person()
	{
		super();
	}
	

	public Person(String firstName, String lastName, gender g) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.g = g;
	}

	void show()
	{
		System.out.println();
		System.out.println("Person Details");
		System.out.println("------------------------------");
		System.out.println("First Name : "+firstName);
		System.out.println("Last Name : "+lastName);
		System.out.println("Gender : "+g);
		System.out.println("Phone Number : "+phoneNumber);
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public gender getG() {
		return g;
	}


	public void setG(gender g) {
		this.g = g;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	
	
}

