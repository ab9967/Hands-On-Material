package NewTwo;

import java.util.Scanner;

public class PersonMain {
	public static void main(String args[])
	{
	Person person = new Person("Aniket","Bhirud",'M');
	Scanner sc = new Scanner(System.in);
	
	String phoneNumber;
	
	System.out.println("Enter phone Number : ");
	phoneNumber = sc.nextLine();
	person.setPhoneNumber(phoneNumber);
	
	System.out.println();
	System.out.println("First Name : "+person.getFirstName());
	System.out.println("Last Name : "+person.getLastName());
	System.out.println("Gender : "+person.getGender());
	System.out.println("Phone Number : "+person.getPhoneNumber());
	sc.close();
	}
}
