class PersonMain
{
	public static void main(String args[])
	{
	Person person = new Person("Aniket","Bhirud",'M');
	System.out.println("First Name : "+person.getFirstName());
	System.out.println("Last Name : "+person.getLastName());
	System.out.println("Gender : "+person.getGender());
	}
}