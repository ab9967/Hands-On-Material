package Lab14_1;

public class PowerLamda {
	public static void main(String[] args) {
		  Power pow = (x,y) -> Math.pow(x, y);
			double result=pow.power(4,2);
			System.out.println(result);
	}
  

}
