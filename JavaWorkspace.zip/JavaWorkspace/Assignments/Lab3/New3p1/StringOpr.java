package New3p1;

public class StringOpr 
{
	public String str;
	
	public StringOpr()
	{
		super();		
	}
	
	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}
	
	public void addStringSelf()
	{
		str = str+ str;
	}
	
	public void replaceOddByHash()
	{
		int length = str.length();
		for(int i=1;i<length;i++)
		{
			str.replace(str.charAt(i),'#');
		}
	}
	
	public void rmDuplicateChars()
	{
		int length = str.length();
		int pos =1;
		char c[] =  str.toCharArray();
		
		for(int i=1;i<length;i++)
		{
			for(int j=0;j<length;j++)
			{
				if(c[i])
			}
		}
	}
}
