package New3p1;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateOperations2 {

	public static void calculatorPeriod(String sdate)
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate givenData  = LocalDate.parse(sdate,formatter);
		System.out.println("given date " +givenData);
		LocalDate today = LocalDate.now();
		System.out.println("Today"+today);
		Period period = givenData.until(today);
		System.out.println("Days : "+period.getDays()+" Months "+period.getMonths()+" Year "+period.getYears());
	}
	
	public static void main(String args[])
	{
		Scanner sc =new Scanner(System.in);
		String date =null; //"01-05-2016";
		
		System.out.println("Enter date and time in the format dd-mm-yyyy");
		date = sc.next();
		sc.close();
		
		calculatorPeriod(date);
	}
}
