package New3p6;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Person {

	public String firstName;
	public String lastName;
	public char gender;
	public LocalDate bdate;
	public String fullName;
	public String bdateStr;
	
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getBdate() {
		return bdateStr;
	}
	public void setBdate(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		bdate  = LocalDate.parse(date,formatter);
		bdateStr = bdate.toString();		
	}
	public String getFullName()
	{
		return firstName+" "+lastName;
	}
	public int getAge()
	{
		LocalDate today = LocalDate.now();
		Period period = bdate.until(today);
		return period.getYears();
	}
	
}
