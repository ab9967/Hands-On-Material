package New3p6;

import java.util.Scanner;

public class PersonMain {

	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
	Person person = new Person();
	
	System.out.println("Enter First Name : ");
	person.setFirstName(sc.next());
	
	System.out.println("Enter Last Name : ");
	person.setLastName(sc.next());
	
	System.out.println("Enter Gender : ");
	person.setGender(sc.next().charAt(0));
		
	System.out.println("Enter Date of Birth : ");
	person.setBdate(sc.next());
	
	sc.close();
	
	System.out.println();
	System.out.println("Person Detials : ");
	System.out.println("------------------");
	System.out.println("Full Name : "+person.getFullName());
	System.out.println("First Name : "+person.getFirstName());
	System.out.println("Last Name : "+person.getLastName());
	System.out.println("Gender : "+person.getGender());
	System.out.println("BirthDate : "+person.getBdate());
	System.out.println("Age : "+person.getAge());
	}
}
