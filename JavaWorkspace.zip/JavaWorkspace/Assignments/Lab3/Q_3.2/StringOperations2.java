package New3p1;

import java.util.Scanner;

public class StringOperations2 {
	static String input;
	static boolean flag = true;
	
	public static void chkPositivity()
	{

		int length = input.length();
		
		char temp[] = input.toCharArray();
		
		for(int i=0;i<length;i++)
		{
			if(length%2 != 0 && i == length-1)
				break;
			
			if(length%2 == 0 && i+1 == length)
				break;
			
			if((int)temp[i]>(int)temp[i+1])
			{
				flag = false;
			}
		}
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		input = sc.next();
		sc.close();
		
		chkPositivity();
		
		if(flag)
		{
			System.out.println("String is Positive.");
		}
		else
		{
			System.out.println("String is Negative.");
		}
		
	}//main
	
	
}
