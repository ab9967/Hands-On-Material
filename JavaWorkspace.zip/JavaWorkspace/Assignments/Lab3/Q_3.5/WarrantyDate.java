package New3p1;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class WarrantyDate {
	
	public static void calculatExpDate(int d,int m,int y, int period)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		Calendar c1 =  Calendar.getInstance();
		c1.set(y, m, d);
		
		System.out.println("Purchase date");
		System.out.println("--------------");
		System.out.println("DD/MM/YYYY");
		System.out.println(sdf.format(c1.getTime()));
		
		System.out.println();
		c1.add(Calendar.YEAR, period);
		System.out.println("Warranty expiry date");
		System.out.println("--------------");
		System.out.println("DD/MM/YYYY");
		System.out.println(sdf.format(c1.getTime()));
	}

	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		int period;
		int pDay,pMonth,pYear;
		
		System.out.println("Enter purchase date");
		System.out.println("--------------------");
		
		System.out.println("Enter Day of Month as DD :");		
		pDay = Integer.parseInt(sc.next());
		
		System.out.println("Enter Month as MM :");
		pMonth = Integer.parseInt(sc.next());
		
		System.out.println("Enter Year as YYYY :");
		pYear = Integer.parseInt(sc.next());
		
		System.out.println("Enter warranty period");
		period = Integer.parseInt(sc.next());
		
		sc.close();
		
		calculatExpDate(pDay, pMonth, pYear, period);
	}
	
}
