package New3p1;

import java.util.Scanner;

public class StringOperations {
	String result;
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringOperations obj = new StringOperations();
		System.out.println("enter the string");
		String string = sc.nextLine();
		while (true)
		{
			System.out.println("1. Add the string to itself" + "\n"
				+ "2. Replace odd positions with #" + "\n"
				+ "3. Remove duplicate characters in the string" + "\n"
				+ "4. Change odd characters to upper case\n"
				+ "5. Exit");
			System.out.println("Please Enter your choice of action");
			int choice = sc.nextInt();
			switch (choice) {
		case 1:
			obj.addString(string, choice);
			break;
		case 2:
			obj.replaceOdd(string, choice);
			break;
		case 3:
			obj.removeDuplicate(string, choice);
			break;
		case 4:
			obj.changeOdd(string, choice);
			break;
		case 5:
			System.exit(0);
			break;
		default:
			System.out.println("Invalid choice.Please check the options");
			}
		System.out.println(obj.result);
		}
	}//main
	
	public String addString(String string, int choice) {
		result = string + string;
		return result;
	}//addString

	public String replaceOdd(String string, int choice) {
		StringBuilder sb = new StringBuilder(string);
		for (int i = 0; i < sb.length(); i++) {

			if (i % 2 != 0) {
				sb.replace(i, i + 1, "#");
			}
		}
		result = new String(sb);
		return result;
	}//replaceOdd

	public String removeDuplicate(String string, int choice) {
		StringBuilder sb = new StringBuilder(string);
		for (int i = 0; i < sb.length(); i++) {
			for (int j = i + 1; j < sb.length(); j++) {
				if (sb.charAt(i) == sb.charAt(j)) {
					sb.delete(i, i + 1);
					break;
				}
			}
		}
		result = new String(sb);
		return result;
	}//removeDuplicate

	public String changeOdd(String string, int choice) {
		StringBuilder sb = new StringBuilder(string);
		for (int i = 0; i < sb.length(); i++) {

			if (i % 2 != 0) {
				char c = sb.charAt(i);
				sb.setCharAt(i, Character.toUpperCase(c));
			}
		}
		result = new String(sb);
		return result;
	}//changeOdd


}
