package New3p1;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class CurrTimeZone {

	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Time Zone ID :");
		String tZone = sc.next();
		sc.close();
		
		ZonedDateTime currTime = ZonedDateTime.now(ZoneId.of(tZone));
		System.out.println("TimeStamp : "+currTime);
	}
}
