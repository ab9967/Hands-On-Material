package Lab14_5;

import java.util.function.Supplier;

public class FactorialMain {
	public static void main(String[] args) {
		Supplier<Factorial> s1 = Factorial::new;
		System.out.println(s1.get().calc(8.0));

	}

}
