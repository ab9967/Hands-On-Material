
class TimerThread implements Runnable 
{	
	public void run() {
		System.out.println("Time's up !!!");
	}
}
public class TimerDemo
{
	public static void main(String args[])
	{
		Thread temp = new Thread();
		TimerThread threadObj = new TimerThread();
		
		while(true)
		{
			try {
				System.out.println("Thread started !");
				threadObj.run();
				temp.sleep(10000);
				
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}