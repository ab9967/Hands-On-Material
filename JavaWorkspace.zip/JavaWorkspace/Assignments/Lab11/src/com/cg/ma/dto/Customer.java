package com.cg.ma.dto;

public class Customer {

	private long purchaseid;
	private String pDate;
	private String Cname;
	private String mailId;
	private String phoneno;

	public Customer(String pDate, String cname, String mailId,
			String phoneno) {
		super();

		this.pDate = pDate;
		Cname = cname;
		this.mailId = mailId;
		this.phoneno = phoneno;
	}

	public Customer() {
		super();
	}

	public String getCname() {
		return Cname;
	}

	public void setCname(String cname) {
		Cname = cname;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getpDate() {
		return pDate;
	}

	public void setpDate(String pDate) {
		this.pDate = pDate;
	}

	public long getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(long purchaseid) {
		this.purchaseid = purchaseid;
	}

	@Override
	public String toString() {
		return "Customer [purchaseid=" + purchaseid
				+ ", pDate=" + pDate + ", Cname=" + Cname + ", mailId="
				+ mailId + ", phoneno=" + phoneno + "]";
	}

}
