package com.cg.ma.Exception;

public class TooLowLimitException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Double lowLimit;

	public TooLowLimitException(Double lowLimit) {
		super();
		this.lowLimit = lowLimit;
	}

	@Override
	public String toString() {
		return "TooLowRangeException : "+lowLimit+" is very low limit and invalid !\nPlease Re-Select Operation !";
	}
	
	

}
