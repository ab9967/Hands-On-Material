package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Customer;
import com.cg.ma.dto.Mobile;
import com.cg.ma.jdbcUtil.DBUtilities;

public class MobileDaoImpl implements IMobileDao {

	Connection conn;
	PreparedStatement pst;
	
	//-----------------------------------------------------------------------------------------------------
	
	public List<Mobile> showAllMobiles() throws MobileException {
		
		conn = DBUtilities.getConnection();
		String query = "Select * from mobiles";
		List<Mobile> mList = new ArrayList<Mobile>();
		
		try {
			pst = conn.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			
			
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				int quantity = rs.getInt(4);
				
				Mobile m = new Mobile();
				
				m.setMobileid(id);
				m.setName(name);
				m.setPrice(price);
				m.setQuantity(quantity);
				
				mList.add(m);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data not found");
			//throw user defined exception
		}
		return mList;
	}

	//-----------------------------------------------------------------------------------------------------
	
	public boolean delMobile(int mobileid) {
		try {
			conn = DBUtilities.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String query = "delete from mobiles where mobileid = ?";
		int count = 0;
		try {
			pst = conn.prepareStatement(query);
			pst.setInt(1, mobileid);
			count = pst.executeUpdate();
			System.out.println(count+" rows deleted.");
			
			if(count > 0)
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
			{
				try {
					pst.close();
					conn.close();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			}
		
		return false;
		
	}

	//-----------------------------------------------------------------------------------------------------
	
	public List<Mobile> searchByRange(double loLimit, double hiLimit) throws MobileException {

		conn = DBUtilities.getConnection();
		String query = "Select * from mobiles where price >= ? AND price <= ?";
		List<Mobile> mList = new ArrayList<Mobile>();		
		
		try {
			pst = conn.prepareStatement(query);
			pst.setDouble(1, loLimit);
			pst.setDouble(2,hiLimit);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				int quantity = rs.getInt(4);
				
				Mobile m = new Mobile();
				
				m.setMobileid(id);
				m.setName(name);
				m.setPrice(price);
				m.setQuantity(quantity);
				
				mList.add(m);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data not found");
		}
		
		return mList;
	}

	//-----------------------------------------------------------------------------------------------------
	
	public boolean updateQuantity(int mobileid, int quantity)
			throws MobileException {
		
		conn = DBUtilities.getConnection();
		String query = "update mobiles set quantity = (select quantity from mobiles where mobileid = ?) - ? where mobileid = ?";
		//(select quantity from mobiles where mobileid = ?)
		int count = 0;
	
		try {
			pst = conn.prepareStatement(query);
			pst.setInt(1, mobileid);
			pst.setInt(2, quantity);
			pst.setInt(3, mobileid);
			count = pst.executeUpdate();
			
			if(count > 0 )
				return true;			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data not updated");
		}
		
		
		// TODO Auto-generated method stub
		return false;
	}

	//-----------------------------------------------------------------------------------------------------
	
	public boolean insertPurchaseDetails(Customer c, String mName, int qty)
			throws MobileException {
		
		conn = DBUtilities.getConnection();
		String query = "insert into purchasedetails(purchaseid, cname, mailid, phoneno, PURCHASEDATE, mobileid) values (?,?,?,?,sysdate,?)"; 
		
		try {
			int mobID = this.getMobileId(mName);		
			//for inserting into purchasedetails
			
			//creating new purchaseID using sequence
			long pidSequence = getPurchaseId();
			//assigning generated sequence to customer purchaseID
			c.setPurchaseid(pidSequence);
			
			pst = conn.prepareStatement(query);
			pst.setLong(1, c.getPurchaseid());
			pst.setString(2 ,c.getCname());
			pst.setString(3, c.getMailId());
			pst.setString(4 , c.getPhoneno());
			pst.setInt(5, mobID);
			int count  =  pst.executeUpdate();
			System.out.println(count + " rows inserted.");
			
			if(this.updateQuantity(mobID, qty))
			{
				return true;
			}
			else
			{
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

		
		return false;
	}
	
	//-----------------------------------------------------------------------------------------------------
	
	public int getMobileId(String name)
	{
		try {
			conn = DBUtilities.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String mobIdQry = "select mobileid from mobiles where name = ?";
		int mobID = 0;
		
		try
		{
		//for fetching mobileid
		pst = conn.prepareStatement(mobIdQry);
		//String name = m.getName();
		pst.setString(1, name);
		ResultSet rs = pst.executeQuery();
		
		while(rs.next())
		{
			mobID = rs.getInt(1);
		}
		System.out.println(" Model Name : "+name + "\n Mobile ID : "+mobID);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return mobID;
	}
	
	//-----------------------------------------------------------------------------------------------------
	//CREATE SEQUENCE purchaseID_seq MINVALUE 10000 MAXVALUE 999999 START WITH 10000 INCREMENT BY 1 CACHE 5;
	public long getPurchaseId() {
		try {
			conn = DBUtilities.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String mobIdQry = "select purchaseID_seq.NEXTVAL from dual";
		long seq = 0;
		try {
			pst = conn.prepareStatement(mobIdQry);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				seq = rs.getLong(1);
			}
			System.out.println("seq number :"+seq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return seq;
	}
	

	/*public static void main(String args[])
	{
		Customer c = new Customer("16-05-2019","King","xyz@gmail.com","9865443223");
		Mobile m = new Mobile(1006,"Google Pixel XL", 60000,1);
		MobileDaoImpl obj = new MobileDaoImpl();
		
		
		try {
			obj.insertPurchaseDetails(c,m);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MobileDaoImpl obj = new MobileDaoImpl();
		List<Mobile> mList = new ArrayList<Mobile>();
		
		try {
			mList = obj.searchByRange(10000, 90000);
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(Mobile index:mList)
		System.out.println(index);
	}*/


}
