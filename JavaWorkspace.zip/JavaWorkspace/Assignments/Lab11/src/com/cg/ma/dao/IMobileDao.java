package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.Customer;
import com.cg.ma.dto.Mobile;

public interface IMobileDao {

	List<Mobile> showAllMobiles() throws MobileException;
	
	boolean delMobile(int mobileid) throws MobileException;
	
	List<Mobile> searchByRange(double loLimit, double hiLimit) throws MobileException;
	
	boolean updateQuantity(int mobileid,int quantity) throws MobileException;
	
	boolean insertPurchaseDetails(Customer c, String mName, int qty) throws MobileException;
	//boolean insertPurchaseDetails(Customer c, String mName) throws MobileException;
	
	long getPurchaseId();
	
	
}
