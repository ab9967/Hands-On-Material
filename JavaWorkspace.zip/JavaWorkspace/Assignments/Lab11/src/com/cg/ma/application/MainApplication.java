package com.cg.ma.application;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ma.Exception.InvalidInputFormatException;
import com.cg.ma.Exception.MobileException;
import com.cg.ma.Exception.TooHighLimitException;
import com.cg.ma.Exception.TooLowLimitException;
import com.cg.ma.dto.Mobile;
import com.cg.ma.service.IMobileService;
import com.cg.ma.service.MobileServiceImpl;

public class MainApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IMobileService serviceRef = new MobileServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		while(true)
		{
			sc = new Scanner(System.in);
			System.out.println("Enter your choice :");
			System.out.println("--------------------");
			System.out.println("1. Show all Mobiles available.");
			System.out.println("2. Delete mobile information from stock.");
			System.out.println("3. Search mobiles.");
			System.out.println("4. Update quantity.");
			System.out.println("5. Record mobile purchase transaction.");
			System.out.println("6. Exit.");
			System.out.println();
			System.out.print("Choice :");
			
			choice = sc.nextInt();
			
			String s = null;
			Pattern pat = null;
			Matcher mat = null;
			switch(choice)
			{				
				//Show all Mobiles
				case 1:
					System.out.println("Mobiles available in store :");
					System.out.println("-----------------------------");
					List<Mobile> list = null;
					try {
						list = serviceRef.showAll();
						//displaying all mobile info from list
						for(Mobile index : list)
							System.out.println(index);
						
						} catch (MobileException e) {
						 // 	TODO Auto-generated catch block
							e.printStackTrace();
						}
					System.out.println();
					break;
				//----------------------------------------------------------------
				//Delete mobile information from stock
				case 2:
					System.out.print("Enter Mobile ID: ");
					Integer id = sc.nextInt();
					
					s = id.toString();
					
					//Mobile ID validation using regular expression
					pat =  Pattern.compile("^[1]{1}[0-9]{2}[0-9]{1}$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					System.out.println("Deleting Mobile information from stock.");
					try {
						boolean flag = serviceRef.deleteMobile(id.intValue());
						if(flag)
						{
							System.out.println("Successful Delete");
						}
						else
						{
							System.out.println("Something went wrong ! Delete incomplete.");
						}
					
					} catch (MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println();
					break;
				//----------------------------------------------------------------
				//Search mobiles
				case 3:
					Double low, high;
					System.out.println("Enter lower and higher price range for searching");
					System.out.print("Lower limit (5 digit amount only) : ");
					low = sc.nextDouble();
					
					s = low.toString();
					
					//low limit's validation using regular expression
					pat = Pattern.compile("^\\d$");
					mat = pat.matcher(s);
					if(mat.matches())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					//will raise exception as TooLowRange as lower limit for range is very low
					if(low<1000)
					{
						try {
							throw new TooLowLimitException(low);
						} catch (TooLowLimitException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							break;
						}
					}
					
					System.out.println();
					System.out.print("Higher limit (5 digit amount only) : ");
					high = sc.nextDouble();
					s = high.toString();
					
					//high limit's validation using regular expression
					pat = Pattern.compile("^\\d$");
					mat = pat.matcher(s);
					if(mat.matches())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					//will raise exception if the higher limit of search range is above 100000
					if(high>100000)
					{
						try {
							throw new TooHighLimitException(high);
						} catch (TooHighLimitException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}					
					
					System.out.println();
					List<Mobile> list1 = null;
					try {
						list1 = serviceRef.searchMobileByRange(low.doubleValue(), high.doubleValue());
						//displaying all mobile info from list
						for(Mobile index : list1)
							System.out.println(index);
						
						} catch (MobileException e) {
						 // 	TODO Auto-generated catch block
							e.printStackTrace();
						}
					System.out.println();
					break;
				//-----------------------------------------------------------------
				//Update quantity.
				case 4:
					Integer id1,qty;
					System.out.println("Enter mobile id and quantity for Updation");
					System.out.print("Enter ID: ");
					id1 = sc.nextInt();
					
					s = id1.toString();
					
					//Mobile ID validation using regular expression
					pat =  Pattern.compile("^[1]{1}[0-9]{2}[0-9]{1}$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					System.out.print("Enter stock sold: ");
					qty = sc.nextInt();
					
					s = qty.toString();
					
					//quantity validation using regular expression
					pat =  Pattern.compile("^\\d$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					
					try {
						boolean flag = serviceRef.updateQty(id1.intValue(), qty.intValue());
						if(flag)
						{
							System.out.println("Successful Update");
						}
						else
						{
							System.out.println("Something went wrong ! Update incomplete.");
						}
					
					} catch (MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println();
					break;
				//-----------------------------------------------------------------
				//Record mobile purchase transaction
				case 5:
					String pDate,cname,mailid,phoneNo,modelName;
					Integer quantity;
					
					System.out.println("Enter details of purchase");
					System.out.print("Enter purchase Date (DD-MM-YYYY) or (DD/MM/YYYY) :");
					pDate = sc.next();
					
					s = pDate;
					
					//purchase date validation using regular expression
					pat =  Pattern.compile("^\\d{2}[-|/]\\d{2}[-|/]\\d{4}$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					System.out.print("Enter Customer name :");
					cname = sc.next();
					
					s = cname;
					
					//customer name validation using regular expression
					pat =  Pattern.compile("^[a-zA-Z]*$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					System.out.print("Enter mail ID :");					
					mailid = sc.next();
					
					s = mailid;
					
					//mail id validation using regular expression
					pat =  Pattern.compile("^[a-zA-Z]*@[a-zA-Z]*.[a-z]*$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					//considering indian mobile numbers only
					System.out.print("Enter phone Number : +91-");					
					phoneNo = sc.next();
					
					s = phoneNo;
					
					//Phone number validation using regular expression
					pat =  Pattern.compile("^[9|8|7]{1}[0-9]{9}$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					
					System.out.println();
					sc.nextLine();
					System.out.print("Enter Model Name :");					
					modelName = sc.nextLine();
					
					s = modelName;
					
					//Model name validation using regular expression
					pat =  Pattern.compile("^[A-Za-z, ]++$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					System.out.print("Enter quantity :");					
					quantity = sc.nextInt();
					
					s = quantity.toString();
					
					//quantity validation using regular expression
					pat =  Pattern.compile("^\\d$");
					mat = pat.matcher(s);
					if(!mat.find())
					{
						try {
							throw new InvalidInputFormatException(s);
						} catch (InvalidInputFormatException e) {
							// TODO Auto-generated catch block
							System.out.println(e);
							break;
						}
					}
					
					System.out.println();
					
					try {
						boolean flag = serviceRef.recordPurchaseDetails(pDate, cname, mailid, phoneNo, modelName, quantity.intValue());
						//boolean flag = serviceRef.recordPurchaseDetails(pDate, cname, mailid, phoneNo, modelName);
						
						if(flag)
						{
							System.out.println("Purchase successful");
						}
						else
						{
							System.out.println("Purchase unsuccessful");
						}
					} catch (MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println();
					break;
				//-----------------------------------------------------------------
				//Exit loop
				case 6:
					System.exit(0);
			}
			
		}
		
	}
	
}
