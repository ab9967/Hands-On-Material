package com.cg.ma.Exception;

public class InvalidInputFormatException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Object input;
	public InvalidInputFormatException(Object input)
	{
		this.input = input;
		System.out.println(input+ " is invalid.");
		System.out.println("Please enter same input one more time !");
	}
	@Override
	public String toString() {
		return "InvalidInputFormatException "+input+ " is invalid.\n Please Re-Select operation.";
	}

	
}
