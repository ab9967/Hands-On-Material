package com.cg.ma.Exception;

public class MobileException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1877716604237334375L;

	String errMsg = null;
	
	public MobileException(String msg)
	{
		errMsg = msg;
	}

	@Override
	public String toString() {
		return "MobileException : error is "+errMsg;
	}
		
}
