package com.cg.ma.Exception;

public class TooHighLimitException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Double highLimit;

	public TooHighLimitException(Double highLimit) {
		super();
		this.highLimit = highLimit;
	}

	@Override
	public String toString() {
		return "TooHighLimitException : "+highLimit+" is very high limit and invalid !\nPlease Re-Select Operation !";
	}
	
	
	
}
