package com.cg.ma.service;

import java.util.List;

import com.cg.ma.Exception.MobileException;
//import com.cg.ma.dto.Customer;
import com.cg.ma.dto.Mobile;

public interface IMobileService {

	List<Mobile> showAll() throws MobileException;
	
	boolean deleteMobile(int mobileid) throws MobileException;
	
	List<Mobile> searchMobileByRange(double loLimit, double hiLimit) throws MobileException;

	boolean updateQty(int mobileid,int quantity) throws MobileException;
	
	boolean recordPurchaseDetails(String pdate, String cname, String mailid, String phoneNo, String modelName, int quantity) throws MobileException;
}
