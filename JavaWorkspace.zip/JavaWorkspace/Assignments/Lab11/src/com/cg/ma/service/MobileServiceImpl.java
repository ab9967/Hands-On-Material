package com.cg.ma.service;

//import java.text.ParseException;
//import java.text.SimpleDateFormat;
import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Customer;
import com.cg.ma.dto.Mobile;

public class MobileServiceImpl implements IMobileService {

	IMobileDao iMobile = new MobileDaoImpl();
	
	public boolean deleteMobile(int mobileid) throws MobileException {
		// TODO Auto-generated method stub
		return iMobile.delMobile(mobileid);
	}

	public List<Mobile> searchMobileByRange(double loLimit, double hiLimit)
			throws MobileException {
		// TODO Auto-generated method stub
		return iMobile.searchByRange(loLimit, hiLimit);
	}

	public List<Mobile> showAll() throws MobileException {
		// TODO Auto-generated method stub
		return iMobile.showAllMobiles();
	}

	public boolean updateQty(int mobileid, int quantity) throws MobileException {
		// TODO Auto-generated method stub
		return iMobile.updateQuantity(mobileid, quantity);
	}

	public boolean recordPurchaseDetails(String pdate, String cname, String mailid, String phoneNo, String modelName, int quantity)
			throws MobileException {
		
		//System.out.println("enter student dob(yyyy/MM/dd) : ");
		Customer c = new Customer(pdate,cname,mailid,phoneNo);
		//Mobile m = new Mobile(1006,modelName, 60000,quantity);
		
		
       /* SimpleDateFormat sfd= new SimpleDateFormat("yyyy/MM/dd");
        try {
			java.util.Date pDate= sfd.parse(pdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return iMobile.insertPurchaseDetails(c, modelName, quantity);
		//return iMobile.insertPurchaseDetails(c, modelName);
	}

}