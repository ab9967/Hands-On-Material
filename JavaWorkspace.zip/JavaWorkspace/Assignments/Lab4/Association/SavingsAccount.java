package Association;

public class SavingsAccount extends Account 
{
	private final double minimumBal = 1000.00;
	private double bal = getBalance();

	public SavingsAccount(long accNum, double balance) {
		super(accNum, balance);
	}
	
	public void withdraw(double amount)
	{
		if((bal-amount)<minimumBal)
		{
			System.out.println("Money withdraw not allowed as balance is going below minimum balance limit !");
			return;
		}
		else
		{
			bal -= amount;
		}
	}

	@Override
	public String toString() {
		return "SavingsAccount [minimumBal=" + minimumBal + "] balance :"+bal;
	}
}
