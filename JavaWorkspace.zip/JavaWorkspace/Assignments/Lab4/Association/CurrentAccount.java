package Association;

public class CurrentAccount extends Account
{
	private final double overdraftLimit = 1000;
	
	private double ttlOverdraft = 0;
	private double bal = getBalance();
	
	public CurrentAccount(long accNum, double balance) {
		super(accNum, balance);
	}
	
	public void withdraw(double amount)
	{
		
		if(amount > bal)
		{
			ttlOverdraft = amount - bal;
			if(ttlOverdraft >= overdraftLimit)
			{
				System.out.println("Overdraft limit Reached !");
				return;
			}
			else
			{
				bal -= amount;
			}
		}
		else
		{
			System.out.println("Overdraft not required !");
			bal -= amount;
		}
	}

	@Override
	public String toString() {
		return "CurrentAccount [overdraftLimit=" + overdraftLimit
				+ ", ttlOverdraft=" + ttlOverdraft + ", bal=" + bal
				+ ", toString()=" + super.toString() + ", getAccNum()="
				+ getAccNum() + ", getBalance()=" + getBalance()
				+ ", getAccHolder()=" + getAccHolder() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
}
