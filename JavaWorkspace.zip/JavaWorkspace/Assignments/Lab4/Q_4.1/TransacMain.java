package Association;

public class TransacMain 
{

	public static void main(String[] args) {
		Person smith = new Person("smith",22);
		Person kathy = new Person("Kathy",23);
		
		System.out.println(smith);
		System.out.println(kathy);
		
		Account smithAcc = new Account(999,2000);
		smithAcc.setAccHolder(smith);
		System.out.println(smithAcc);
		
		Account kathyAcc = new Account(999,3000);
		kathyAcc.setAccHolder(kathy);
		System.out.println(kathyAcc);
		System.out.println();
		
		smithAcc.deposit(2000);
		
		kathyAcc.withdraw(2000);
		
		System.out.println("Smith account balance :"+smithAcc.getBalance());
		System.out.println("Kathy account balance :"+kathyAcc.getBalance());
	}

}
