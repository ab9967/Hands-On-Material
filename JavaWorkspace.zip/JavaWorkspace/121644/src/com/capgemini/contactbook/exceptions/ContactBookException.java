/****************************************************************
*File 					:ContactBookException.java
*Author 			:Capgemini	
*Description 		:Exception class
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.exceptions;

public class ContactBookException extends Exception {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContactBookException() {
		
	}

	public ContactBookException(String message) {
		super(message);
		
	}

	public ContactBookException(Throwable cause) {
		super(cause);
		
	}

	public ContactBookException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ContactBookException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

}
