/****************************************************************
*File 					:EnquiryException.java
*Author 			:Capgemini	
*Description 		:Exception class
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.exceptions;

public class EnquiryException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EnquiryException() {
		super();
		
	}

	public EnquiryException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public EnquiryException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public EnquiryException(String message) {
		super(message);
		
	}

	public EnquiryException(Throwable cause) {
		super(cause);
		
	}

	
	
}
