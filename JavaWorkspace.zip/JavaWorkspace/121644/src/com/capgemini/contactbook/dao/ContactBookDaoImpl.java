/****************************************************************
*File 					:ContactBookDaoImpl.java
*Author 			:Capgemini	
*Description 		:Dao Class of application
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;

public class ContactBookDaoImpl implements ContactBookDao {

	Connection conn;
	PreparedStatement pst;
	static final Logger logs = Logger.getLogger(ContactBookDaoImpl.class);
	
	public ContactBookDaoImpl() {
		
	}

	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		/*
		 * this method will return 1 for success in adding Enquiry to database
		 * or will return 0 for failure in adding Enquiry to database
		 * */
		
		//getting connection
		conn = com.capgemini.contactbook.util.DBUtilities.getConnection();
		//query for inserting booking ticket details
		String query = "insert into enquiry(enqryId, firstName, lastName, contactNo, domain,city) values (?,?,?,?,?,?)";
		int enquiryID  = this.getEnquiryID();
		enqry.setEnqryId(enquiryID);
		int count = 0;
		
		try {
			
			pst = conn.prepareStatement(query);
			pst.setInt(1, enqry.getEnqryId());
			pst.setString(2, enqry.getfName());
			pst.setString(3, enqry.getlName());
			pst.setLong(4, Long.parseLong(enqry.getContactNo()));
			pst.setString(5, enqry.getpDomain());
			pst.setString(6, enqry.getpLocation());
			
			count = pst.executeUpdate();
			logs.info(count +" row inserted in enquiry table");
			
			if(count>=1)
				{
				 	return enquiryID;
				 }
			else
			{
				return 0;
			}
			
		} catch (SQLException e) {
			logs.error("Book Ticket failure !");
			throw new  ContactBookException("Failure in Adding enquiry to database !!!"+e);
		}
	}
	private int  getEnquiryID() throws ContactBookException
	{
				//getting connection
				conn = com.capgemini.contactbook.util.DBUtilities.getConnection();
				// query
				String query = "select enquiries.NEXTVAL from dual";
				int enquiryID = 0;
				
				try {
					pst = conn.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					while(rs.next())
					{
						enquiryID = rs.getInt(1);
					}
					logs.info("Booking ID: "+enquiryID+" Generated.");
					
				} catch (SQLException e) {
					logs.error("enquiry ID Generation failure !");
					throw new ContactBookException("Failure in generation of Enquiry ID !"+e);
				}				
				return enquiryID;		
	}
	
	
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		
		conn = com.capgemini.contactbook.util.DBUtilities.getConnection();
		String query = "Select * from enquiry where enqryId = ?";
		
		try {
			pst = conn.prepareStatement(query);
			pst.setInt(1, EnquiryID);
			ResultSet rs = pst.executeQuery();
						
			EnquiryBean eBean = new EnquiryBean();
			eBean.setEnqryId(EnquiryID);
			
			if(rs.next())
			{
				String fName= rs.getString("firstName");
				String lName = rs.getString("lastName");
				Long contactNoLong = rs.getLong("contactNo");
				String contactNo = contactNoLong.toString();
				String pLocation = rs.getString("city");
				String pDomain = rs.getString("domain");
				
				
				eBean.setfName(fName);
				eBean.setlName(lName);
				eBean.setContactNo(contactNo);
				eBean.setpLocation(pLocation);
				eBean.setpDomain(pDomain);
				
				logs.info("Enquiry Fetch Successful");
				
				return eBean;
			}
			else
			{
				logs.info("Enquiry Fetch Unsuccessful");
				return null;
			}
			
		} catch (SQLException e) {
			
			logs.error("Enquiry Fetch Unsuccessful !!!");
			throw new ContactBookException("Enquiry not found"+e);
			//throw user defined exception
		}finally
		{
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				logs.error("Enquiry Fetch Resource unable to close  !!!");
				throw new ContactBookException("Unable to close resources !!!"+e);
			}
		}
	}

}
