/****************************************************************
*File 					:ContactBookDao.java
*Author 			:Capgemini	
*Description 		:Dao interface
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;

public interface ContactBookDao
{
		public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
		public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException; 
}
