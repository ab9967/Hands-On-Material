/****************************************************************
*File 					:ContactBookServiceImpl.java
*Author 			:Capgemini	
*Description 		:Service Class of application
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService {

	static final Logger logs = Logger.getLogger(ContactBookServiceImpl.class);
	ContactBookDaoImpl dao;
	
	public ContactBookServiceImpl() {
		dao = new ContactBookDaoImpl();
	}

	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
					
		return dao.addEnquiry(enqry);
	}

	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		
		return dao.getEnquiryDetails(EnquiryID);
	}

	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
			boolean cNo = this.validateContactNo(enqry.getContactNo());
			boolean fName = this.validateFirstName(enqry.getfName());
			boolean lName = this.validateLastName(enqry.getlName());
			boolean location = this.validatePLocation(enqry.getpLocation());
			boolean domain = this.validatePDomain(enqry.getpDomain());
			
			if(cNo&&fName&&lName&&location&&domain)
			{
				return true;
			}
			else
			{
				return false;
			}			
	}
	
	public boolean validateContactNo(String contactNo)
	{
		Pattern pat = null;
		Matcher mat = null;
		
		String s = contactNo;

		// Phone number validation using regular expression
		pat = Pattern.compile("^[9|8|7]{1}[0-9]{9}$");
		mat = pat.matcher(s);
		if (!mat.find()) {
				logs.error("Invalid Contact No Format :"+s);
				return false;
			
		}		
		return true;		
	}
	public boolean validateFirstName(String fName)
	{
		Pattern pat = null;
		Matcher mat = null;
		
		String s = fName;

		if(s.length()==0)
		{
			logs.error("Invalid first Name Format (empty input)");
			return false;
		}
		
		// first name validation using regular expression
		pat = Pattern.compile("^[a-zA-Z]*$");
		mat = pat.matcher(s);
		if (!mat.find()) {
			logs.error("Invalid first Name Format :"+s);
			return false;
				
		}
		return true;
	}
	public boolean validateLastName(String lName)
	{
		Pattern pat = null;
		Matcher mat = null;
		
		String s = lName;

		if(s.length()==0)
		{
			logs.error("Invalid last Name Format(empty input)");
			return false;
		}
		
		// customer name validation using regular expression
		pat = Pattern.compile("^[a-zA-Z]*$");
		mat = pat.matcher(s);
		if (!mat.find()) {
			logs.error("Invalid last Name Format :"+s);
			return false;
		}
		return true;
	}
	public boolean validatePLocation(String loc)
	{
		Pattern pat = null;
		Matcher mat = null;
		
		String s = loc;

		if(s.length()==0)
		{
			logs.error("Invalid location Format(empty input)");
			return false;
		}
		
		//location validation using regular expression
		pat = Pattern.compile("^[a-zA-Z]*$");
		mat = pat.matcher(s);
		if (!mat.find()) {
			logs.error("Invalid location Format :"+s);
			return false;
		}
		return true;
	}
	public boolean validatePDomain(String domain)
	{
		Pattern pat = null;
		Matcher mat = null;
		
		String s = domain;

		if(s.length()==0)
		{
			logs.error("Invalid domain Format (empty input):");
			return false;
		}
		
		// customer name validation using regular expression
		pat = Pattern.compile("^[a-zA-Z]*$");
		mat = pat.matcher(s);
		if (!mat.find()) {
			logs.error("Invalid domain Format :"+s);
			return false;
		}
		return true;
	}	
}
