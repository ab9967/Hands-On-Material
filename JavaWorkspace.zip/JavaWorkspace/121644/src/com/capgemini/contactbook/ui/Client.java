/****************************************************************
*File 					:Client.java
*Author 			:Capgemini	
*Description 		:Main UI of program
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.ui;


import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.exceptions.EnquiryException;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class Client {

	static ContactBookServiceImpl  services = new ContactBookServiceImpl();
	static final Logger logs = Logger.getLogger(Client.class);
	
	public Client() {
		super();		
	}

	public static void main(String[] args) throws ContactBookException, EnquiryException 
	{
		logs.info("Application Started !");
		int choice = 0;
		System.out.println("***********************Global Recruitments***************************");
		Scanner sc = new Scanner(System.in);
		do
		{
			printMenu();
			choice = sc.nextInt();
	
			switch (choice) {
			case 1:
				{
					//Scanner sc1 = new Scanner(System.in);
					
					System.out.print("Enter First Name : ");
					String fName = sc.next();
					
					System.out.print("Enter Last Name : ");
					String lName = sc.next();
					
					System.out.print("Enter Contact Number : ");
					String contactNo = sc.next();
					
					System.out.print("Enter  Preferred Domain : ");
					String domain = sc.next();
					
					System.out.print("Enter  Preferred Location :");
					String location = sc.next();
					System.out.println();
					System.out.println("**********************");
					
					EnquiryBean enqry = new EnquiryBean();
					enqry.setfName(fName);
					enqry.setlName(lName);
					enqry.setContactNo(contactNo);
					enqry.setpDomain(domain);
					enqry.setpLocation(location);
					int enqID = 0;
					try
					{
						/*if(services.isValidEnquiry(enqry))
						{*/
							enqID = services.addEnquiry(enqry);
					/*	}
						else
						{
							sc1.close();
							logs.info("application failed  due to invalid input !");
							throw new EnquiryException("Exception in Adding due to invalid input !");
						}*/
					}
					catch(Exception e)
					{
						sc.close();
						throw new EnquiryException("Exception in Adding !",e);						
					}
					if(enqID != 0 )
					{
						System.out.println("Thank you "+fName+" "+lName+" your Unique Id is "+enqID+" we will contact you shortly.");
					}
					else
					{
						logs.info(" Unable to Add Enquiry at Client !!!");
					}
					
					break;
				}
			case 2:
				{
					//Scanner sc2 = new Scanner(System.in);
					System.out.println("**********************");
					System.out.println("Enter Enquiry No.  : ");
					String enqNoStr = sc.next();
					System.out.println("**********************");
					int enqNo = Integer.parseInt(enqNoStr);
					
					EnquiryBean eBean = new EnquiryBean();					
					try
					{
						eBean = services.getEnquiryDetails(enqNo);
					}
					catch(Exception e)
					{
						sc.close();
						throw new EnquiryException("Exception in Fetching !",e);
					}
					if(eBean!=null)
					{
						System.out.println("Id\tFirst Name\tLast Name\tContact No.\tPreferred Domain\tPreferred Location");
						System.out.println(eBean);
					}
					else
					{ 
						logs.info("No details found for : "+enqNo);
						System.out.println("Sorry no details found!!");
					}
					
					break;
				}
			case 3:
				{
					System.out.println("Thank you selecting us !!");
					logs.info("APPLICATION CLOSED !");
					System.exit(0);
					break;
				}
			}
		//	sc.nextLine();
		}while(choice!=3);
		sc.close();
		System.exit(0);
	}

	public static  void printMenu()
	{
		
		System.out.println("Choose an operation");
		System.out.println("1. Enter Enquiry Details");
		System.out.println("2. View Enquiry Details in ID");
		System.out.println("3. Exit");
		System.out.println("**********************");
		System.out.print("Please enter a choice : ");
	}
}
