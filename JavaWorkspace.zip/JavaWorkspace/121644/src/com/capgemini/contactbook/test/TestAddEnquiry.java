/****************************************************************
*File 					:TestAddEnquiry.java
*Author 			:Capgemini	
*Description 		:Test case for AddEnquiry method in dao layer
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/


package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;

public class TestAddEnquiry {

	EnquiryBean eBean = new EnquiryBean();
	ContactBookDaoImpl dao = new ContactBookDaoImpl();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		
		eBean.setfName("Ram");
		eBean.setlName("Sharma");
		eBean.setContactNo("7865327411");
		eBean.setpDomain("Java");
		eBean.setpLocation("Chennai");
	}

	@After
	public void tearDown() throws Exception {
		eBean = null;
	}

	@Test
	public void test() throws ContactBookException {
		assertNotNull(dao.addEnquiry(eBean));
	}

}
