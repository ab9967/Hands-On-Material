/****************************************************************
*File 					:TestViewEnqiry.java
*Author 			:Capgemini	
*Description 		:Test case for getEnquiryDetails method in dao layer
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;

public class TestViewEnqiry {

	int EnqID=0;
	ContactBookDaoImpl dao = new ContactBookDaoImpl();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		EnqID = 1003;
	}

	@After
	public void tearDown() throws Exception {
		EnqID=0;
	}

	@Test
	public void testGetEnquiryDetails() throws ContactBookException {
		assertNotNull(dao.getEnquiryDetails(EnqID));
	}

}
