/****************************************************************
*File 					:TestConnection.java
*Author 			:Capgemini	
*Description 		:Test case for testing connection to database
*Last date modified :18-03-2017
*Version 			:1.0
*****************************************************************/

package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contactbook.util.DBUtilities;

public class TestConnection {
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		assertNotNull(DBUtilities.getConnection());
	}

}
