package JdbcJavaDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Sample 
{
	public static void main(String args[])
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String url = "jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G";
		try(Connection con = DriverManager.getConnection(url,"labg104trg16","labg104oracle");)
		{
			if(con != null)
			{
				/*System.out.println("Connected\n");
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery("Select * from employees");
				//index of resultset starts from 1
				System.out.println("EMPID \t NAME");
				System.out.println("------\t-------");
				while(rs.next())
				{
					int empId = rs.getInt(1);
					String fname = rs.getString(2);
					System.out.println(empId+" \t "+fname);
				}*/
				
				Statement stmt = con.createStatement();
				int rowCount = stmt.executeUpdate("insert into dept values (50,'SUPPORT','SEATTLE')");
				System.out.println(rowCount+ " row inserted.");
				
				rowCount = 0;
				rowCount = stmt.executeUpdate("Delete from dept where deptno = 50");
				System.out.println(rowCount+ " row deleted.");
				
				rowCount = 0;
				rowCount = stmt.executeUpdate("Update dept set loc = 'SEATTLE' where deptno = 10");
				System.out.println(rowCount+ " row Updated.");
				
				rowCount = 0;
				rowCount = stmt.executeUpdate("Update dept set loc = 'NEW YORK' where deptno = 10");
				System.out.println(rowCount+ " row Updated.");
			}
		}catch(SQLException e)
		{
			System.out.println(e);
		}
	}
}
