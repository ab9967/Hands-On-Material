package com.cg.empmgmt.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.empmgmt.jdbcUtil.*;

public class Test {

	public static void main(String args[])
	{
		Connection con = null;
		PreparedStatement pst = null;
		con = DBUtilities.getConnection();
		if(con != null)
		{
			System.out.println("Connected");
		}
		else
		{
			System.out.println("Not Connected");
			System.exit(0);
		}
		
		String query = "insert into dept(deptno, dname, loc) values (?,?,?)";
		String delQuery = "delete from dept where deptno = ?";
		String updateQuery = "update dept set loc = ? where deptno = ?";
		
		try {
			pst = con.prepareStatement(query);
			pst.setInt(1,50);
			pst.setString(2,"SUPPORT");
			pst.setString(3, "SEATTLE");
			int count = pst.executeUpdate();
			System.out.println(count + " rows inserted.");
			
			pst.setInt(1,60);
			pst.setString(2,"RESEARCH");
			pst.setString(3, "AUSTIN");
			count = pst.executeUpdate();
			System.out.println(count + " rows inserted.");

//			count = 0;
			pst = con.prepareStatement(delQuery);
			pst.setInt(1, 50);
			count = pst.executeUpdate();
			System.out.println(count + " rows deleted.");
			
//			count = 0;
			pst = con.prepareStatement(delQuery);
			pst.setInt(1, 60);
			count = pst.executeUpdate();
			System.out.println(count + " rows deleted.");
			
//			count = 0;
			pst = con.prepareStatement(updateQuery);
			pst.setString(1, "LONDON");
			pst.setInt(2, 10);
			count = pst.executeUpdate();
			System.out.println(count + " rows updated.");
			
//			count = 0;
			pst = con.prepareStatement(updateQuery);
			pst.setString(1, "NEW YORK");
			pst.setInt(2, 10);
			count = pst.executeUpdate();
			System.out.println(count + " rows updated.");
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
