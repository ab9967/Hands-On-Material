package callableStatements;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.cg.empmgmt.jdbcUtil.*;

public class CallableDemo {

	public static void main(String args[])
	{
		Connection conn = null;
		CallableStatement Callstmt = null;
		String query = "{ call getSalary(?,?) }";
				
		conn = DBUtilities.getConnection();
		if(conn != null)
		{
			System.out.println("Connected");
		}
		else
		{
			System.out.println("Not Connected");
			System.exit(0);
		}
		
		try {
			Callstmt = conn.prepareCall(query);
			Callstmt.setInt(1 , 108);
			Callstmt.registerOutParameter(2, java.sql.Types.INTEGER);
			Callstmt.execute();
			
			int Sal = Callstmt.getInt(2);
			System.out.println("Salary : " +Sal);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
