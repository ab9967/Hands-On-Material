package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.dto.UserDTO;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.JndiUtil;

public class RegisterDAOImpl implements RegisterDAO{

	UserDTO user = null;
	JndiUtil util = null;
	
	public RegisterDAOImpl() {
		
		user = new UserDTO();
		
		try {
			util = new JndiUtil();
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean registerUser(String fname, String lname, String password,
			String gender, String skills, String city) {
		
		user.setFname(fname);
		user.setLname(lname);
		user.setPassword(password);
		user.setGender(gender);
		user.setSkills(skills);
		user.setCity(city);
		
		String genderTemp;
		if(user.getGender().equals("Male"))
			{genderTemp = "M";}
		else
			{genderTemp = "F";}
		
		Connection conn = null;
		PreparedStatement pst = null;
		
		String query = "	INSERT INTO RegisteredUsers VALUES (?,?,?,?,?,?)";
		int count = 0;
		
		try {
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, user.getFname());
			pst.setString(2, user.getLname());
			pst.setString(3, user.getPassword());
			pst.setString(4, genderTemp);
			pst.setString(5, user.getSkills());
			pst.setString(6, user.getCity());
			
			count = pst.executeUpdate();
			if(count >= 1 )
			{
				System.out.println(count +"row inserted.");
				return true;
			}
			else 
			{
				System.out.println(count +"row inserted.");
				return false;
			}
			
		} catch (SQLException e) {
			System.out.println("Exception in JNDIUtil : "+e);
			//e.printStackTrace();
		}	
		
		return false;
	}

	@Override
	public List<UserDTO> showRegisteredUsers() {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = "SELECT * FROM RegisteredUsers";
		
		List<UserDTO> userList = new ArrayList<UserDTO>();
		
		try {
					
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			
			rs = pst.executeQuery();
			
			while(rs.next())
			{
				String fname = rs.getString(1);
				String lname = rs.getString(2);
				String password = rs.getString(3);
				String gender = rs.getString(4);
				String skills = rs.getString(5);
				String city = rs.getString(6);
				
				UserDTO user = new UserDTO(fname,lname,password,gender,skills,city);
				
				userList.add(user);	
				
			}
			
		} catch (SQLException e) {
			try {
				throw new UserException("JNDI Failed."+e);
			} catch (UserException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
				System.out.println("Exception : "+e);
			}
		}
		finally
		{
			if(rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					
					try {
						throw new UserException("JNDI connection closing Failed.");
					} catch (UserException e1) {
						
						System.out.println("Exception : "+e);
					}
				}
			
			if(pst != null)
				try {
					pst.close();
				} catch (SQLException e) {
					
					try {
						throw new UserException("JNDI connection closing Failed.");
					} catch (UserException e1) {
						
						//e1.printStackTrace();
						System.out.println("Exception : "+e);
					}
				}
			
			if(conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					
					try {
						throw new UserException("JNDI connection closing Failed.");
					} catch (UserException e1) {
						
						//e1.printStackTrace();
						System.out.println("Exception : "+e);
					}
				}
			
		}
		
		return userList;
	}
}
