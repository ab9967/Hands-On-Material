package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.dto.UserDTO;

public interface RegisterDAO {
	boolean registerUser(String fname, String lname, String password, String gender, String skills, String city);
	
	List<UserDTO> showRegisteredUsers();
}
