package com.cg.appl.services;

import java.util.List;

public interface RegisterService {
	
	boolean registerUser(String fname, String lname, String password, String gender, String skills, String city);

	List showRegisteredUsers();
}
