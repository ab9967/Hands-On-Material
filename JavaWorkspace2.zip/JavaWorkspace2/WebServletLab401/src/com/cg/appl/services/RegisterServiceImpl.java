package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.RegisterDAO;
import com.cg.appl.daos.RegisterDAOImpl;
import com.cg.appl.dto.UserDTO;

public class RegisterServiceImpl implements RegisterService {

	private RegisterDAO serviceRef;
	
	public RegisterServiceImpl() {
		serviceRef = new RegisterDAOImpl();
	}

	@Override
	public boolean registerUser(String fname, String lname, String password,
			String gender, String skills, String city) {
		
		if(serviceRef.registerUser(fname, lname, password, gender, skills, city))
		{
			System.out.println("Registration Success !!!");
			return true;
		}
		else
		{
			System.out.println("Registration Failure !!!");
			return false;
		}	
	}

	@Override
	public List<UserDTO> showRegisteredUsers() {	
		
		return serviceRef.showRegisteredUsers();
	}

}
