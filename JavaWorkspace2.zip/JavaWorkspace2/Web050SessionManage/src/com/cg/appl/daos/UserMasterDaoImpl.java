package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.JdbcUtil;
import com.cg.appl.util.JndiUtil;

public class UserMasterDaoImpl implements UserMasterDao
{
	/*private JdbcUtil util;*/
	private JndiUtil util;
	
	public UserMasterDaoImpl() throws UserException
	{
		/*util = new JdbcUtil();*/
		util = new JndiUtil();
	}
	
	@Override
	public User getUserDetials(String userName) throws UserException {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = "SELECT password, userfname FROM users WHERE username = ?";
		try {
					
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1,userName);
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				String password = rs.getString("password");
				String fullName = rs.getString("userfname");
				
				User user = new User(userName, password, fullName);
				return user;
				
			}
			else
			{
				throw new UserException("UserName wrong.");
			}
			
		} catch (SQLException e) {
			throw new UserException("JDBC Failed."+e);
		}
		finally
		{
			if(rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					
					throw new UserException("JDBC connection closing Failed.");
				}
			
			if(pst != null)
				try {
					pst.close();
				} catch (SQLException e) {
					
					throw new UserException("JDBC connection closing Failed.");
				}
			
			if(conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					
					throw new UserException("JDBC connection closing Failed.");
				}
			
		}
	}

}