package com.cg.appl.services;

import com.cg.appl.daos.UserMasterDao;
import com.cg.appl.daos.UserMasterDaoImpl;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
public class UserMasterServicesImpl implements UserMasterServices {	
	private UserMasterDao dao;
	
	public UserMasterServicesImpl() throws UserException
	{
		dao = new UserMasterDaoImpl();
	}	
	@Override
	public User getUserDetials(String userName) throws UserException {
		
		return dao.getUserDetials(userName);
	}
	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws UserException {
		User user = dao.getUserDetials(userName);
		
		if(password.equals(user.getPassword()))
		{
		 return true;	
		}
		else
		{
		 return false;
		}
	}
	
}
