package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
/*
 * @WebServlet("/*.do")
 * 	this line can be a cause for project not getting deployed on server so avoid / in *.do 
 * */
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	private String nextJsp;
	private RequestDispatcher dispatch;
	private String message = null;
	ServletContext ctx = null;
	
	
	public void init() throws ServletException {
		ctx = super.getServletContext();
		services = (UserMasterServices) ctx.getAttribute("services");
		try {
			services = new UserMasterServicesImpl();
			
		} catch (UserException e) {
			 
			ctx.getRequestDispatcher("/error.jsp");
			RequestDispatcher dispatch = ctx.getRequestDispatcher("/error.jsp");
			ctx.log(e.getMessage());
			
		}
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String command = request.getServletPath();
		System.out.println("Command : "+command);
		ctx.log("Command : "+command);
		switch(command)
		{
		 case "/login.do":
			{
				nextJsp = "/login.jsp";
				break;
			}//end of case for login.do
			
		 case "/authenticate.do":
			{
				String userName = request.getParameter("userName");
				String pwd = request.getParameter("password");
				
				try {
					boolean isAuthenticated = services.isUserAuthenticated(userName, pwd);
					if(isAuthenticated)
					{
						System.out.println("Yes");
						
						//redirecting control from servlet to other jsp file
						//on server all files are stored on root folder
						//request for dispatching control
						/*dispatch = request.getRequestDispatcher("/mainMenu.jsp");*/
						//for handing over the control to other jsp file
						/*dispatch.forward(request, response);*/
						
						//code for starting new session
						User user =  services.getUserDetials(userName);
						HttpSession session = request.getSession(true);
						System.out.println(session.getId());
						session.setAttribute("user", user);
						
						nextJsp = "/mainMenu.jsp";
						
					}
					else
					{
						System.out.println("No");
						
						/*dispatch = request.getRequestDispatcher("/login.jsp");
						dispatch.forward(request, response);*/
						
						message = "Wrong Credentials Entered !!!";
						request.setAttribute("errorMsg", message);
						ctx.log("error Message : "+message);
						nextJsp = "/login.jsp";
					}
					
					
				} catch (UserException e) {
					
					/*dispatch = request.getRequestDispatcher("/error.jsp");
					dispatch.forward(request, response);*/
					nextJsp = "/error.jsp";
					ctx.log(e.getMessage());
					message = "User Name does not exist !!!";
					request.setAttribute("errorMsg", message);
					
					//e.printStackTrace();
				}
				break;
			} //end of case for authenticate.do
			
		 case "/logout.do":
			{
				HttpSession session = request.getSession(false);
				session.invalidate(); //destroying session
				nextJsp = "/login.jsp";
				break;
			}//end of case for logout.do
		}
		
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	public void destroy() {
		services = null;
	}
}
