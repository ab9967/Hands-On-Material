/****************************************************************
*File 				: IShowDAO.java
*Author 			:Capgemini	
*Description 		: Interface file for ShowDAO Class
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.dao;

import java.util.List;

import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;

public interface IShowDAO {

	public List<Show> getAllShows();
	
	public boolean[] isSold();
	
	public boolean bookTicket(Customer customer , String showName);
	
	public Show getShowDetails(String sID);
}
