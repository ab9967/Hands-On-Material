/****************************************************************
*File 				: ShowController.java
*Author 			:Capgemini	
*Description 		: Controller
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
//import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;
import com.cg.otba.services.IShowService;
import com.cg.otba.services.ShowService;

/**
 * Servlet implementation class ShowController
 */
@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	IShowService serviceRef;
	//ServletContext ctx = null;
	Show shoObj;
	private RequestDispatcher dispatch;
	Customer customer;
	
    public ShowController() {
        super();
       dispatch = null;
        serviceRef = new ShowService();
        customer = new Customer();
    }

	
	public void init(ServletConfig config) throws ServletException {
		
		//ctx = super.getServletContext();
		//serviceRef = (IShowService) ctx.getAttribute("services");
		serviceRef = new ShowService();
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String nextJsp = null;
		String path = request.getServletPath();
		List<Show> shoList = new ArrayList<Show>();
		boolean[] isSold = new boolean[5];
		if(path.equals("/home.do"))
		{
			System.out.println("In controller");
			shoList = serviceRef.getAllShows();
			
			isSold = serviceRef.isSold();
			
			/*for(int i=0;i)*/
			request.setAttribute("isSold", isSold);
			request.setAttribute("showList", shoList);
			nextJsp = "/showDetails.jsp";
		}
		else if(path.equals("/bookNow.do"))
		{
			String sID = request.getParameter("showId");
			
			Show temp = serviceRef.getShowDetails(sID);
			
			request.setAttribute("showID" ,temp.getShowID());
			request.setAttribute("showName" ,temp.getShowName());
			request.setAttribute("priceTicket", temp.getPriceTicket());
			request.setAttribute("avSeats", temp.getAvSeats());
			request.setAttribute("maxLimit", temp.getAvSeats());

			nextJsp = "/bookNow.jsp";
		}		
		else if(path.equals("/bookTicket.do"))
		{
			String showName = request.getParameter("sName");
			customer.setCustomerName(request.getParameter("cName"));
			customer.setMobNumber(request.getParameter("mNumber"));
			customer.setNoOfSeats(Integer.parseInt(request.getParameter("noOfSeats")));
			
			Show shoObj = new Show();
			String sID = request.getParameter("sID");
			shoObj = serviceRef.getShowDetails(sID);
			if(	shoObj.getAvSeats()<=0)
			{
				request.setAttribute("customerName", customer.getCustomerName());
				request.setAttribute("sName", shoObj.getShowName());
				nextJsp = "ticketBookingException.jsp";
				dispatch = request.getRequestDispatcher(nextJsp);
				dispatch.forward(request,response);
			}
			else
			{			
				boolean isUpdated = serviceRef.bookTicket(customer, showName);
				
				if(isUpdated)
				{
					nextJsp = "/success.jsp";
					request.setAttribute("showName", showName);
					request.setAttribute("customer", customer);
					request.setAttribute("showPrice", request.getParameter("sPrice"));
				}
				else
				{
					request.setAttribute("showName", showName);
					request.setAttribute("customer", customer);
					nextJsp = "/error.jsp";
				}
			}
		}
		
		
		
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
	}
	
}
