/****************************************************************
*File 				: Customer.java
*Author 			:Capgemini	
*Description 		: DTO class for Customer entity
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.dto;

public class Customer {

	private String customerName;
	private String mobNumber;
	private int noOfSeats;
	public Customer() {
		super();
		
	}
	public Customer(String customerName, String mobNumber, int noOfSeats) {
		super();
		this.customerName = customerName;
		this.mobNumber = mobNumber;
		this.noOfSeats = noOfSeats;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(String mobNumber) {
		this.mobNumber = mobNumber;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	
	
	
}
