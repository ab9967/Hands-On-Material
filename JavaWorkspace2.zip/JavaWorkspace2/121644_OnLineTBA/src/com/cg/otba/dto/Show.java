/****************************************************************
*File 				: Show.java
*Author 			:Capgemini	
*Description 		: DTO class for Magic Show entity
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.dto;

import java.time.LocalDate;

public class Show {
	
	private String showID;
	private String showName;
	private String location;
	private LocalDate showDate;
	private int avSeats;
	private double priceTicket;
	
	
	public Show() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Show(String showID, String showName, String location,
			LocalDate showDate, int avSeats, double priceTicket) {
		super();
		this.showID = showID;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.avSeats = avSeats;
		this.priceTicket = priceTicket;
	}


	public String getShowID() {
		return showID;
	}
	public void setShowID(String showID) {
		this.showID = showID;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public LocalDate getShowDate() {
		return showDate;
	}
	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}
	public int getAvSeats() {
		return avSeats;
	}
	public void setAvSeats(int avSeats) {
		this.avSeats = avSeats;
	}
	public double getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(double priceTicket) {
		this.priceTicket = priceTicket;
	}

	
	
}
