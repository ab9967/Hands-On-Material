/****************************************************************
*File 				: TicketBookingException.java
*Author 			:Capgemini	
*Description 		: Exception class for handling user defiened exceptions for ticket booking
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.exceptions;

public class TicketBookingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TicketBookingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TicketBookingException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public TicketBookingException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public TicketBookingException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TicketBookingException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
