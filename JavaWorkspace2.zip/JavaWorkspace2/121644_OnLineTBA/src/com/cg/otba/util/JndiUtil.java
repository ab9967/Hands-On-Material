/****************************************************************
*File 				: JndiUtil.java
*Author 			:Capgemini	
*Description 		: Utility class for getting Database connection using JNDI
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.otba.exceptions.TicketBookingException;

public class JndiUtil {
	private DataSource dataSource;
	
	public JndiUtil() throws TicketBookingException {
		try {
			Context ctx  = new InitialContext(); 		//get reference to remote JNDI
			
			dataSource = (DataSource)ctx.lookup("java:/OracleDS"); //proxy of dataSource
			
			
		} catch (NamingException e) {
			
			e.printStackTrace();
			
			throw new TicketBookingException("Failed to get JNDI context"+e);
		}
	}
	
	public Connection getConnection() throws SQLException
	{
		System.out.println("Connected");
		//all sysout messages at server level are implicitly implemented as INFO logs
		return dataSource.getConnection();
		
	}


}
