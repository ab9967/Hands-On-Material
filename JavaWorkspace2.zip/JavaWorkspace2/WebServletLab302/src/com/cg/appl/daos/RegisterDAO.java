package com.cg.appl.daos;

public interface RegisterDAO {
	boolean registerUser(String fname, String lname, String password, String gender, String skills, String city);
}
