package com.cg.appl.dto;

public class UserDTO {

	private String fname, lname,password,gender,skills,city;
	
	public UserDTO() {
				
	}

	public UserDTO(String fname, String lname, String password, String gender,
			String skills, String city) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.password = password;
		this.gender = gender;
		this.skills = skills;
		this.city = city;
	}
	
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	
	
}
