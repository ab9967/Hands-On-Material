package com.cg.appl.services;

public interface RegisterService {
	
	boolean registerUser(String fname, String lname, String password, String gender, String skills, String city);

}
