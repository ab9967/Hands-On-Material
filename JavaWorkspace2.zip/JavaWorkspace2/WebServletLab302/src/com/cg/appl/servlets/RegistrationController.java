package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.services.RegisterService;
import com.cg.appl.services.RegisterServiceImpl;

@WebServlet("/registerUsersURL")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private RegisterService services = null;
	private RequestDispatcher dispatch;
	
	RegistrationController()
	{
		services = new RegisterServiceImpl();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				String fname = request.getParameter("fname");
				String lname = request.getParameter("lname");
				String password = request.getParameter("pwd");
				String gender = request.getParameter("gender");
				String[] skill = request.getParameterValues("skill");
				String city = request.getParameter("city");
				String nextJsp = null;
				
				String skills = "";
				
				if(skill != null)
				{
					for(int i=0;i<skill.length;i++)
					{
						skills += (skill[i]+",");
					}
				}
				
				System.out.println(skills);
				
				/*System.out.println(fname+lname+password+gender+skill+city);*/
				
				if(services.registerUser(fname, lname, password, gender, skills, city))
				{
					System.out.println("Registration Done !");
					nextJsp = "/success.jsp";
				}
				else
				{
					System.out.println("Registration Failed !");
					nextJsp = "/failure.jsp";
				}
				
				dispatch = request.getRequestDispatcher(nextJsp);
				dispatch.forward(request,response);
				
	}

}
