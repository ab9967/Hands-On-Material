select * from RegisteredUsers;
