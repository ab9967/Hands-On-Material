package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
//import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalcInterest
 */
//declaring config parameters in servlet fileonly
@WebServlet(urlPatterns = "/calcInterest" , initParams={@WebInitParam(name ="x", value ="50")})
public class CalcInterest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private float rateInterest;
	
	public void init() throws ServletException {
		ServletContext ctx = super.getServletContext();
		String rateInterestStr = ctx.getInitParameter("rateInterest");
		rateInterest = Float.parseFloat(rateInterestStr);
		System.out.println("From init() : "+rateInterest);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext ctx = super.getServletContext();
		String rateInterestStr = ctx.getInitParameter("rateInterest");
		rateInterest = Float.parseFloat(rateInterestStr);
		System.out.println("From service() : "+rateInterest);
		System.out.println(ctx.getContextPath());
		System.out.println(ctx.getMajorVersion());
		System.out.println(ctx.getMinorVersion());
		System.out.println(ctx.getServerInfo());
		System.out.println(ctx.getServletContextName());
		
		ServletConfig cfg = super.getServletConfig();
		String xStr = cfg.getInitParameter("x");
		//int x = Integer.parseInt(xStr);
		System.out.println("From doGet() calcInterest : config param x = "+xStr);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
