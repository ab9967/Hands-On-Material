package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AnotherServlet
 */
//@WebServlet("/anotherServlet")
public class AnotherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private float rateInterest;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletContext ctx = super.getServletContext();
		String rateInterestStr = ctx.getInitParameter("rateInterest");
		rateInterest = Float.parseFloat(rateInterestStr);
		System.out.println("From doGet() another : "+rateInterest);		
		
		ServletConfig cfg = super.getServletConfig();
		String xStr = cfg.getInitParameter("x");
		int x = Integer.parseInt(xStr);
		System.out.println("From doGet() another : config param x = "+x);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
