package com.cg.ebill.dto;

public class BillDTO {

	private double billNum	, curReading, lastReading, unitConsumed, netAmount;
	private long consumerNum;
	public final int FixedCharge = 100;
	
	public BillDTO() {
		
	}
	
	public BillDTO(double billNum, long consumerNum, double curReading,
 double lastReading,	double unitConsumed, double netAmount) {
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		this.curReading = curReading;
		this.lastReading = lastReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
	}

	public double getBillNum() {
		return billNum;
	}

	public void setBillNum(double billNum) {
		this.billNum = billNum;
	}

	public long getConsumerNum() {
		return consumerNum;
	}

	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}

	public double getCurReading() {
		return curReading;
	}

	public void setCurReading(double curReading) {
		this.curReading = curReading;
	}

	public double getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public double getLastReading() {
		return lastReading;
	}

	public void setLastReading(double lastReading) {
		this.lastReading = lastReading;
	}
		
}
