package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import com.cg.ebill.dto.BillDB;
import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.exception.UserException;
import com.cg.ebill.util.JndiUtil;

public class EBillDAOImpl implements EBillDAO {

	private JndiUtil util = null;
	Connection conn = null;
	PreparedStatement pst = null;
	
	public EBillDAOImpl() throws BillException {
		util = new JndiUtil();
	}

	@Override
	public BillDTO calcEBill(BillDTO eBill, ConsumerDTO consumer) {
		BillDTO tempBill;
		//valiDate Consumer
		boolean validConsumer = this.validateConsumer(consumer);
		if(validConsumer)
		{	
			//unit consumed calculation
			double unitsConsumed = eBill.getCurReading() - eBill.getLastReading();
			eBill.setUnitConsumed(unitsConsumed);
			eBill.setConsumerNum(consumer.getConsumerNo());
			double billNo = this.getBillNumber();
			eBill.setBillNum(billNo);
			
			//net Amount calculation
			double netAmount = (unitsConsumed*1.15)+eBill.FixedCharge;
			eBill.setNetAmount(netAmount);
			
			//insert bill data of consumer
			tempBill = this.insertBillData(eBill);
			return tempBill;
		}
		else
		{
			return null;
		}

	}

	
	private BillDTO insertBillData(BillDTO bill)
	{
		String query = "INSERT INTO BillDetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) VALUES(?,?,?,?,?,sysdate)"; 
		
		try {
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			
			pst.setDouble(1, bill.getBillNum());
			pst.setLong(2, bill.getConsumerNum());
			pst.setDouble(3, bill.getCurReading());
			pst.setDouble(4, bill.getUnitConsumed());
			pst.setDouble(5, bill.getNetAmount());
			
			int count = pst.executeUpdate();
			
			if(count >= 1)
			{
				System.out.println(count + "row inserted.");
				return bill;
			}
		} catch (SQLException e) {

			System.out.println("Exception in insert bill"+e);
			//e.printStackTrace();
		}
		
		return null;		
	}
	
	private double getBillNumber()
	{
		ResultSet rs = null;
		double billNo = 0;
		String query = "SELECT seq_bill_num.nextVal FROM DUAL";
		
		try {
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			
			rs = pst.executeQuery();
			if(rs.next())
			{
				billNo = rs.getDouble(1);
			}
			return billNo;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			try {
				throw new BillException("Exception while generating bill number !!!"+e);
				
			} catch (BillException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
			}
		}
		return billNo;
		
	}
	
	private boolean validateConsumer(ConsumerDTO consumer)
	{
		ResultSet rs = null;
		
		String query = "SELECT * FROM Consumers WHERE consumer_num = ?"; 
		
		try {
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			pst.setLong(1, consumer.getConsumerNo());
			
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				return true;
			}
			else
			{
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in validating consumer !!!" +e);
		}
			
		return false;
	}
	
	
	@Override
	public User userAuthentication(String userName)
			throws UserException {
		//System.out.println(userName);
		ResultSet rs = null;
		String query = "SELECT password FROM users WHERE username = ?";
		try {
					
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1,userName);
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				String password = rs.getString("password");
								
				User user = new User();
				user.setUserName(userName);
				user.setPassword(password);
				return user;
				
			}
			else
			{
				throw new UserException("UserName wrong.");
			}
			
		} catch (SQLException e) {
			throw new UserException("JNDI Failed."+e);
		} finally
		{
			if(rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					
					throw new UserException("JNDI connection closing Failed.");
				}
			if(pst != null)
				try {
					pst.close();
				} catch (SQLException e) {
					
					throw new UserException("JNDI connection closing Failed.");
				}
			
			if(conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					
					throw new UserException("JNDI connection closing Failed.");
				}
	     }
		/*User user = new User();
		String username = "Aniket";
		String password = "aniket123";
		
			user.setUserName("Aniket");
			user.setPassword(password);
			if(userName.equals(username))
			{
				System.out.println("Login success !!!");
		}
		else
		{
			throw new UserException("Invalid UserName !!!");
		}
		return user;*/
  }

	@Override
	public ConsumerDTO getConsumer(long consumerNo) {
		ResultSet rs = null;
		ConsumerDTO tempConsumer = new ConsumerDTO();
		String  query = "SELECT * FROM Consumers WHERE consumer_num = ?";
		
		try {
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			pst.setLong(1, consumerNo);
			
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				tempConsumer.setConsumerNo(rs.getLong("consumer_num"));
				tempConsumer.setConsumerName(rs.getString("consumer_name"));
				tempConsumer.setConsumerAddress(rs.getString("address"));
				return tempConsumer;
			}
			else
			{
				throw new Exception("Unable to get ConsumerData !!!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in getting consumer from DB !!!" +e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in getting consumer from DB !!!" +e);
		}

		return null;
	}

	@Override
	public boolean storeToDB(BillDTO eBill) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ConsumerDTO> getConsumerList() {
		List<ConsumerDTO> cList = new ArrayList<ConsumerDTO>();
		ResultSet rs = null;
		
		String query = "SELECT * FROM Consumers"; 
		
		try {
			conn = util.getConnection();
			pst = conn.prepareStatement(query);	
			
			rs = pst.executeQuery();
			
			while(rs.next())
			{
				ConsumerDTO consumer = new ConsumerDTO(rs.getLong("CONSUMER_NUM"),rs.getString("CONSUMER_NAME"),rs.getString("ADDRESS"));
				
				cList.add(consumer);
			}
			
			return cList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in getting consumer List !!!" +e);
		}
			
		return null;
	}

	@Override
	public List<BillDB> getConsumerBills(long consumerNo) {
		List<BillDB> cList = new ArrayList<BillDB>();
		ResultSet rs = null;
		
		String query = "SELECT * FROM billDetails WHERE CONSUMER_NUM = ?"; 
		
		try {
			conn = util.getConnection();
			pst = conn.prepareStatement(query);	
			pst.setLong(1,consumerNo);
			
			rs = pst.executeQuery();
			
			while(rs.next())
			{
				BillDB cBill = new BillDB();
				
				cBill.setBillNum(rs.getDouble("BILL_NUM"));
				cBill.setConsumerNum(rs.getLong("CONSUMER_NUM"));
				cBill.setCurReading(rs.getDouble("CUR_READING"));
				cBill.setUnitConsumed(rs.getDouble("UNITCONSUMED"));
				
				Date sqlDate = rs.getDate("BILL_DATE");
				LocalDate lDate = sqlDate.toLocalDate();
				Month month = lDate.getMonth();
				/*System.out.println(lDate.getDayOfMonth());
				System.out.println(lDate.getMonthValue());
				System.out.println(lDate.getYear());
				System.out.println(lDate.getDayOfMonth()+"/"+lDate.getMonthValue()+"/"+lDate.getYear());*/
				
				String mon = month.toString();
				
				cBill.setMonth(mon);
				cBill.setNetAmount(rs.getDouble("NETAMOUNT"));
				
				cList.add(cBill);
			}
			
			return cList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in getting consumer Bills !!!" +e);
		}
			
		return null;
	}
}