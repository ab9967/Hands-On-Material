package com.cg.employeemgmt.dto;

public class Employee {

	private int empId;
	private String empQualification;
	private String empName;
	private double empSal;
	
	public Employee() {
		
	}
	
	public Employee(int empId, String empQualification, String empName,
			double empSal) {
		super();
		this.empId = empId;
		this.empQualification = empQualification;
		this.empName = empName;
		this.empSal = empSal;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpQualification() {
		return empQualification;
	}

	public void setEmpQualification(String empQualification) {
		this.empQualification = empQualification;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empQualification="
				+ empQualification + ", empName=" + empName + ", empSal="
				+ empSal + "]";
	}
	
	
}
