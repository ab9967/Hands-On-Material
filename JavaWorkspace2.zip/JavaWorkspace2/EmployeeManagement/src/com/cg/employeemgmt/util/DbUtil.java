package com.cg.employeemgmt.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.employeemgmt.exception.EmployeeException;

public class DbUtil {

	static Connection conn = null;
	private static DataSource dataSource;
	
	public static Connection obtainConnection() throws EmployeeException
	{
		Context ctx;
		try {
			ctx = new InitialContext();  //get reference to remote JNDI
			
			dataSource = (DataSource)ctx.lookup("java:/OracleDS"); //proxy of dataSource
			
			conn =  dataSource.getConnection();
			
		} catch (NamingException e) {
			
			e.printStackTrace();
			throw new EmployeeException("Exception in Connection"+e);
		} 		
		catch (SQLException e) {
			
			e.printStackTrace();
			throw new EmployeeException("Exception in Connection"+e);
		}
		return conn;	
	}
}
