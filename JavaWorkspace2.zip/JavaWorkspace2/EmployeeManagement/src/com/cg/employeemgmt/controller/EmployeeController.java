package com.cg.employeemgmt.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.employeemgmt.dto.Employee;
import com.cg.employeemgmt.exception.EmployeeException;
import com.cg.employeemgmt.service.EmployeeService;


@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     private EmployeeService service;
    
    public EmployeeController() {
        super();
        service = new EmployeeService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in GET"+e);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in POST"+e);
		}
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, EmployeeException 
	{
		String path = request.getServletPath();
		//System.out.println(path);
		RequestDispatcher dispatch = null;		
		
		if(path.equals("/empl.do"))
		{
			dispatch = request.getRequestDispatcher("/addEmployee.jsp");
			dispatch.forward(request, response);
		}
		if(path.equals("/empAdd.do"))
		{
			String name = request.getParameter("eName");
			String qual = request.getParameter("eQualification");
			String sal = request.getParameter("eSal");
			Employee emp = new Employee();
			emp.setEmpName(name);
			emp.setEmpQualification(qual);
			emp.setEmpSal(Double.parseDouble(sal));
			
			try {
				int empID = service.addEmployee(emp);
				System.out.println(empID);
				/*if(flag >= 1)
				{
					System.out.println("Data Insertion Success !!!");
				}*/
				request.setAttribute("empID", empID);
				dispatch = request.getRequestDispatcher("/welcome.jsp");
				dispatch.forward(request, response);
				
			} catch (EmployeeException e) {
			System.out.println("Exception in controller : "+e);
				//e.printStackTrace();
			}
		}
		if(path.equals("/showAll.do"))
		{
			List<Employee>  empList = service.showAll();
			
			/*for(Employee index:empList)
			{
				System.out.println(index);
			}*/
			
			request.setAttribute("employeeList", empList);
			dispatch = request.getRequestDispatcher("/viewList.jsp");
			dispatch.forward(request, response);
			
		}
		if(path.equals("/update.do"))
		{
			System.out.println("Update");
			String id = request.getParameter("id");
			/*
			 * String data = request.getQueryString(); o/p =>  id=1010
			 * String eID = data.substring(3,7);
			 * */
			System.out.println(id);
			Employee emp = service.getEmployee(Integer.parseInt(id));
			/*System.out.println(emp);*/
			request.setAttribute("emp", emp);
			dispatch = request.getRequestDispatcher("/updateEmployee.jsp");
			dispatch.forward(request, response);
			
		}
		if(path.equals("/updateData.do"))
		{
			Employee emp = new Employee();
			emp.setEmpId(Integer.parseInt(request.getParameter("Eid")));
			emp.setEmpName(request.getParameter("eName"));
			emp.setEmpQualification(request.getParameter("eQual"));
			emp.setEmpSal(Double.parseDouble(request.getParameter("eSal")));
			
			boolean flag = service.updateData(emp);
			if(flag)
			{
				System.out.println("Data Update success !!!");
				dispatch = request.getRequestDispatcher("/showAll.do");
				dispatch.forward(request, response);
			}
		}
		if(path.equals("/delete.do"))
		{
			System.out.println("Delete");
			String id = request.getParameter("id");
			System.out.println(id);
			boolean flag = service.deleteData(Integer.parseInt(id));
			System.out.println(flag);
			if(flag)
			{
				System.out.println("Data Delete success !!!");
				dispatch = request.getRequestDispatcher("/showAll.do");
				dispatch.forward(request, response);
			}
			
		}
	}
}