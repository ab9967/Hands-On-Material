package com.cg.employeemgmt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemgmt.dto.Employee;
import com.cg.employeemgmt.exception.EmployeeException;
import com.cg.employeemgmt.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao{

	Connection conn = null;
	PreparedStatement pst = null;
	int empId;
	public EmployeeDaoImpl() {
		
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException{
		
		empId = this.getEmployeeID();
		String query = "INSERT INTO EMPLOYEEMANAGEMENT VALUES(?,?,?,?)";
		
		try {
			conn = DbUtil.obtainConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, empId);
			pst.setString(2, emp.getEmpName());
			pst.setString(3, emp.getEmpQualification());
			pst.setDouble(4, emp.getEmpSal());
			
			int count = pst.executeUpdate();
			if(count >= 1)
			{
				System.out.println(count + "row inserted");
				return empId;
			}
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao : "+e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao : "+e);
		} finally
		{
			try {
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("Exception in Dao IMPL : "+e);
			}			
		}		
		return 0;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		
		String query = "SELECT * FROM EMPLOYEEMANAGEMENT";
		List<Employee> empList = new ArrayList<Employee>();
		
		try {
			conn = DbUtil.obtainConnection();
			pst = conn.prepareStatement(query);
			
			ResultSet rs = pst.executeQuery(); 
			
			while(rs.next())
			{
				Employee e = new Employee();
				
				e.setEmpId(rs.getInt("EMP_ID"));
				e.setEmpName(rs.getString("EMP_NAME"));
				e.setEmpQualification(rs.getString("EMP_QUAL"));
				e.setEmpSal(rs.getDouble("EMP_SAL"));
				
				empList.add(e);
			}
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			
				throw new EmployeeException("Exception in DAO showAll : "+e);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return empList;
	}

	public int getEmployeeID() throws EmployeeException
	{
		String query = "SELECT empID_seq.nextVal FROM DUAL";
		/*
		 * create sequence empID_seq START WITH 1003;
		 * */
		try {
			conn = DbUtil.obtainConnection();
			pst = conn.prepareStatement(query);
			
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				empId = rs.getInt(1);
			}
			
		} catch (EmployeeException e) {
			
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao : "+e);
		} catch (SQLException e) {
			
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao : "+e);
		} finally
		{
			try {
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				
				//e.printStackTrace();
				System.out.println("Exception in Dao IMPL : "+e);
			}			
		}		
		return empId;
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		
		String query = "SELECT * FROM EMPLOYEEMANAGEMENT WHERE EMP_ID=?";
		Employee e = new Employee();		
		
		try {
			conn = DbUtil.obtainConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();			
			
			if(rs.next())
			{				
				
				e.setEmpId(rs.getInt("EMP_ID"));
				e.setEmpName(rs.getString("EMP_NAME"));
				e.setEmpQualification(rs.getString("EMP_QUAL"));
				e.setEmpSal(rs.getDouble("EMP_SAL"));
				
			}
			
		} catch (EmployeeException e1) {
			//e.printStackTrace();
			
				throw new EmployeeException("Exception in DAO getEmployee : "+e1);
			
		} catch (SQLException e1) {
			//e1.printStackTrace();
			
		}		
		return e;
	}
	
	public boolean updateData(Employee emp) throws EmployeeException
	{
		String query = "Update EMPLOYEEMANAGEMENT Set emp_Name = ? , emp_Qual = ? ,emp_Sal = ? WHERE EMP_ID = ?";
		
		try {
			conn = DbUtil.obtainConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, emp.getEmpName());
			pst.setString(2, emp.getEmpQualification());
			pst.setDouble(3, emp.getEmpSal());
			pst.setInt(4, emp.getEmpId());
			int count = pst.executeUpdate();
			if(count >= 1)
			{
				System.out.println(count + "row updated");
				return true;
			}
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao update : "+e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao update : "+e);
		} finally
		{
			try {
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("Exception in Dao IMPL update : "+e);
			}			
		}		
		
		return false;
	}

	@Override
	public boolean deleteData(int empID) throws EmployeeException {
		String query = "DELETE FROM EMPLOYEEMANAGEMENT WHERE EMP_ID=?";
		
		try {
			conn = DbUtil.obtainConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, empID);
			int count = pst.executeUpdate();
			if(count >= 1)
			{
				System.out.println(count + "row deleted");
				return true;
			}
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao delete : "+e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new EmployeeException("Exception in Dao delete : "+e);
		} finally
		{
			try {
				pst.close();
				conn.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("Exception in Dao IMPL delete : "+e);
			}			
		}		
		return false;
	}
	
	
}
