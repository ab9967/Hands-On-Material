package com.cg.employeemgmt.service;

import java.util.List;

import com.cg.employeemgmt.dto.Employee;
import com.cg.employeemgmt.exception.EmployeeException;

public interface IEmployeeService {

	public int addEmployee(Employee emp) throws EmployeeException;	
	public List<Employee> showAll() throws EmployeeException;
	public Employee getEmployee(int id) throws EmployeeException;
	public boolean updateData(Employee emp) throws EmployeeException;
	public boolean deleteData(int empID) throws EmployeeException;
}
