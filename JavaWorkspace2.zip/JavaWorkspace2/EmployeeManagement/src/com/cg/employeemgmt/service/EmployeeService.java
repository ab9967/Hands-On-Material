package com.cg.employeemgmt.service;

import java.util.List;

import com.cg.employeemgmt.dao.EmployeeDaoImpl;
import com.cg.employeemgmt.dao.IEmployeeDao;
import com.cg.employeemgmt.dto.Employee;
import com.cg.employeemgmt.exception.EmployeeException;

public class EmployeeService implements IEmployeeService {

	IEmployeeDao empDao;
	
	public EmployeeService() {
		empDao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		
		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		
		return empDao.showAll();
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		
		return empDao.getEmployee(id);
	}

	@Override
	public boolean updateData(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.updateData(emp);
	}

	@Override
	public boolean deleteData(int empID) throws EmployeeException {
		
		return empDao.deleteData(empID);
	}
}