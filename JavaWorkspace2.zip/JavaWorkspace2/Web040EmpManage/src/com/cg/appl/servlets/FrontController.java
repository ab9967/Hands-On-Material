package com.cg.appl.servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmpServices services;
	private String nextJsp;
	private RequestDispatcher dispatch;
	
	
	public void init() throws ServletException {
		services = new EmpServicesImpl();
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String command = request.getServletPath();
		System.out.println("Command : "+command);
		
		switch(command)
		{
		 case "/acceptEmpNo.do":
			{
				nextJsp = "/acceptEmpNo.jsp";
				break;
			}
		 case "/showEmpDetials.do":
			{
				try {
					
					String empNoStr = request.getParameter("empNo");
					System.out.println(empNoStr);
					int empNo = Integer.parseInt(empNoStr);
					Employee emp = services.getEmployeeDetials(empNo);
					request.setAttribute("emp", emp);//request Scope
					nextJsp = "/showEmpDetails.jsp";
					
					
				} catch (NumberFormatException e) {
					request.setAttribute("errorMsg", "Wrong Employee number Input !!!");
					nextJsp = "/error.jsp";
				} catch (EmpException e) {
					request.setAttribute("errorMsg", "Employee Number does not exist !!!");
					nextJsp = "/error.jsp";
				}
				break;
			}
		 /*case "/getEmpDetails.do":
			{
			
				break;
			}*/
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	public void destroy() {
		services = null;
	}
}
