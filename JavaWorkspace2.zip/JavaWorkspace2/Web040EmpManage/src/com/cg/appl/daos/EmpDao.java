package com.cg.appl.daos;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao {
	
	Employee getEmployeeDetials(int empNo) throws EmpException;

}
