package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entities.Employee;

import com.cg.appl.exceptions.EmpException;

import com.cg.appl.util.JdbcUtil;

public class EmpDaoImpl implements EmpDao {

	private JdbcUtil util;
	
	public EmpDaoImpl() {
		util = new JdbcUtil();
	}

	@Override
	public Employee getEmployeeDetials(int empNo) throws EmpException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = "SELECT empno, ename, sal FROM emp WHERE empno = ?";
		try {
					
			conn = util.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1,empNo);
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				String empName = rs.getString("ename");
				float empSal = rs.getFloat("sal");
				
				Employee emp = new Employee(empNo, empName, empSal);
				return emp;
				
			}
			else
			{
				throw new EmpException("Employee No. wrong.");
			}
			
		} catch (SQLException e) {
			throw new EmpException("JDBC Failed."+e);
		}
		finally
		{
			if(rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					
					throw new EmpException("JDBC connection closing Failed."+e);
				}
			
			if(pst != null)
				try {
					pst.close();
				} catch (SQLException e) {
					
					throw new EmpException("JDBC connection closing Failed."+e);
				}
			
			if(conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					
					throw new EmpException("JDBC connection closing Failed."+e);
				}
			
		}
	}

}
