package com.cg.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
	
	private OracleDataSource dataSource;
	//generates pool of connection instead of single connection which increases scalability of application
	
	public JdbcUtil()
	{
		
		try {
			
			
			dataSource = new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
			dataSource.setUser("labg104trg16");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
						
			
		}catch (SQLException e) {
			
			e.printStackTrace();
		} finally
		{
			
		}
				
	}
	
	public Connection getConnection() throws SQLException
	{
		System.out.println("Connected");
		//all sysout messages at server level are implicitly implemented as INFO logs
		return dataSource.getConnection();
		
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void finalize() throws Throwable {
		
		dataSource.close();
		super.finalize();
	}	
	
}
