package com.cg.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

public class TestUtil {

	public boolean testConnection()
	{
		JndiUtil obj = new JndiUtil();
		
		try {
			Connection conn = obj.getConnection();
			
			if(conn != null)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			
			System.out.println("Exception : "+e.getMessage());
		}
		return false;
	}
	
}
