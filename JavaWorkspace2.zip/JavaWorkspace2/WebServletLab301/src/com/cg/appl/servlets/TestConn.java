package com.cg.appl.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.util.TestUtil;

/**
 * Servlet implementation class TestConn
 */
@WebServlet("/testConnURL")
public class TestConn extends HttpServlet {
	private static final long serialVersionUID = 1L;
    TestUtil test = null;
	
	public TestConn()
	{
		test = new TestUtil();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean flag = test.testConnection();
		
		PrintWriter out = response.getWriter();
		
		if(flag)
		{
			out.write("Connection Successful !!!");
		}
		else
		{
			out.write("Connection Failure :-[] ");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
