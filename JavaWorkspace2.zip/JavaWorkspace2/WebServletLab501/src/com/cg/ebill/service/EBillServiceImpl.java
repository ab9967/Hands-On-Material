package com.cg.ebill.service;

import com.cg.ebill.dao.EBillDAO;
import com.cg.ebill.dao.EBillDAOImpl;
import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.exception.UserException;

public class EBillServiceImpl implements EBillService {

	EBillDAO billDAORef;
	
	public EBillServiceImpl() throws BillException {
		billDAORef = new EBillDAOImpl();
	}

	@Override
	public BillDTO calcEBill(BillDTO eBill, ConsumerDTO consumer) {
		BillDTO tempBill = new BillDTO();
		tempBill = billDAORef.calcEBill(eBill, consumer);
		if(tempBill != null)
		{
			return tempBill;
		}
		else
		{
			return null;
		}
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws UserException {
		User user = billDAORef.userAuthentication(userName);
		if(user.getPassword().equals(password))
		{
			System.out.println("Login success !!!");
			return true;
		}
		else
		{
			System.out.println("Login failure !!!");
			return false;
		}
	}

	@Override
	public ConsumerDTO getConsumer(long consumerNo) {
		
		ConsumerDTO tempC = new ConsumerDTO();
		
		tempC = billDAORef.getConsumer(consumerNo);
		if(tempC != null)
		{
			return tempC;
		}
		else
		{
			System.out.println("GEt consumer failed in Service");
			return null;
		}
		
	}

}
//call validate consumer