package com.cg.ebill.service;

import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.exception.UserException;

public interface EBillService {

	BillDTO calcEBill(BillDTO eBill, ConsumerDTO consumer);
	
	boolean isUserAuthenticated(String userName, String password) throws UserException;
	
	ConsumerDTO getConsumer(long consumerNo);
}