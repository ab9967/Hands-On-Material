package com.cg.appl.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


@WebListener
public class ManageCartListener implements HttpSessionListener {

  
     public void sessionCreated(HttpSessionEvent arg0)  { 
         System.out.println("In session listener Creation");
     }

	
    public void sessionDestroyed(HttpSessionEvent arg0)  { 
         System.out.println("In session listener destroyed");
    }
	
}
