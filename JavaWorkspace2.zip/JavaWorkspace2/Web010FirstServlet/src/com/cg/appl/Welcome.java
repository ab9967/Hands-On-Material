package com.cg.appl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/welcome")
public class Welcome extends HttpServlet
{
	
	private static final long serialVersionUID = 1L;
	private int visits = 0;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("Message on console !!!"+request.getPathInfo());
		//getPathInfo browser sends data to request object
		//response is for sending data to browser
		System.out.println("Method Type "+request.getMethod());
		//method used in form is retrieved like post,get
		System.out.println("Message on console "+request.getServletPath());
		//retrieves URL
		
		PrintWriter out = response.getWriter();
		out.write("Welcome !"+(++visits));
	}

	@Override
	public void destroy() {		
		System.out.println("In Destroy()");
		super.destroy();
		//super.destroy(); calls destructer hence all implementation task must be done before it
	}

	@Override
	public void init() throws ServletException {
		//super.init(); calls def constructor hence all init implementation must be after this
		super.init();
		
		System.out.println("In init()");
	}

}