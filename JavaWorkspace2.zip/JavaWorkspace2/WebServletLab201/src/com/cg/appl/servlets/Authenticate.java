package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String username = "Aniket";
	private String password = "aniket123";
	public void init() throws ServletException
	{
		
		//can be overridden
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uName = request.getParameter("userName");
		String pwd = request.getParameter("password");
		
		RequestDispatcher dispatch = null;
		String nextJsp = null;
		
		if(uName.equals(username)&&pwd.equals(password))
		{	
			nextJsp = "/success.jsp";
		}
		else
		{
			nextJsp = "/failure.jsp";
		}
		
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
	}	
	public void destroy() {
		
	}
}
