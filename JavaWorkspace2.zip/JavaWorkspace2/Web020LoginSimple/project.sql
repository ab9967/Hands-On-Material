select * from emp;

create table users
(
	username varchar2(15) primary key,
	password varchar2(15),
	userfname varchar2(40)
);

insert into users (username, password, userfname) values ('abc','abc','abcabc');
insert into users (username, password, userfname) values ('xyz','xyz','xyzxyz');

select * from users;