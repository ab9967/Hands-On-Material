package com.cg.appl.tests;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;

public class TestUser {

	private static UserMasterServices services;
	
	@BeforeClass
	public static void initialize()
	{
		services = new UserMasterServicesImpl();
	}	
	@Test
	public void testGetUserDetials() {
		
		try {
			User user = services.getUserDetials("abc");
			String actualPassword = "abc";
			
			Assert.assertEquals(user.getPassword(), actualPassword);
			
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
