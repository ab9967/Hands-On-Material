package com.cg.appl.util;

import java.sql.SQLException;

public class TestUtil {

	public static void main(String args[])
	{
		JdbcUtil obj = new JdbcUtil();
		
		try {
			obj.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
