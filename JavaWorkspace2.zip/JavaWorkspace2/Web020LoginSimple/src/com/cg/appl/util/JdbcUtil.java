package com.cg.appl.util;

//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
//import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
	//private Properties prop;
	//private InputStream in;
	private OracleDataSource dataSource;
	//generates pool of connection instead of single connection which increases scalability of application
	
	public JdbcUtil()
	{
		//prop = new Properties();
		//String url/*,driver*/,uname,pwd;
		try {
			/*in = new FileInputStream("D:\\JavaWorkspace2\\Web020LoginSimple\\WebContent\\META-INF\\oracle.properties");
			prop.load(in);
			url = prop.getProperty("oracle.url");
			//driver = prop.getProperty("oracle.driver");
			uname = prop.getProperty("oracle.uname");
			pwd = prop.getProperty("oracle.pwd");*/
			
			dataSource = new OracleDataSource();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
			dataSource.setUser("labg104trg16");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
						
			
		} /*catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}*/catch (SQLException e) {
			
			e.printStackTrace();
		} finally
		{
			/*try {
				in.close();
				
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}*/
		}
				
	}
	
	public Connection getConnection() throws SQLException
	{
		System.out.println("Connected");
		//all sysout messages at server level are implicitly implemented as INFO logs
		return dataSource.getConnection();
		
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void finalize() throws Throwable {
		
		dataSource.close();
		super.finalize();
	}	
	
}
