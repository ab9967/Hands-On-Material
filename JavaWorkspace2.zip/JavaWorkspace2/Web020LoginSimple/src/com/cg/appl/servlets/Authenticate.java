package com.cg.appl.servlets;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
// import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	
	/*public void init(ServletConfig config) throws ServletException
	{
		services = new UserMasterServicesImpl();
		//this init method with config param cannot be overridden if done causes exceptions
	}*/

	public void init() throws ServletException
	{
		services = new UserMasterServicesImpl();
		//can be overridden
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String pwd = request.getParameter("password");
		
		System.out.println(userName+"\t"+pwd);
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String pwd = request.getParameter("password");
		
		RequestDispatcher dispatch = null;
		
		String nextJsp = null;
		String message = null;
		
		try {
			boolean isAuthenticated = services.isUserAuthenticated(userName, pwd);
			if(isAuthenticated)
			{
				System.out.println("Yes");
				
				//redirecting control from servlet to other jsp file
				//on server all files are stored on root folder
				//request for dispatching control
				/*dispatch = request.getRequestDispatcher("/mainMenu.jsp");*/
				//for handing over the control to other jsp file
				/*dispatch.forward(request, response);*/
				
				nextJsp = "/mainMenu.jsp";
				
			}
			else
			{
				System.out.println("No");
				
				/*dispatch = request.getRequestDispatcher("/login.jsp");
				dispatch.forward(request, response);*/
				
				message = "Wrong Credentials Entered !!!";
				request.setAttribute("errorMsg", message);
				
				nextJsp = "/login.jsp";
			}
			
			
		} catch (UserException e) {
			
			/*dispatch = request.getRequestDispatcher("/error.jsp");
			dispatch.forward(request, response);*/
			nextJsp = "/error.jsp";
			
			message = "User Name does not exist !!!";
			request.setAttribute("errorMsg", message);
			
			//e.printStackTrace();
		}		
		
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
		/*System.out.println(userName+"\t"+pwd);*/
		/*super.doPost(request, response);*/
	}	
	public void destroy() {
		
	}
}
