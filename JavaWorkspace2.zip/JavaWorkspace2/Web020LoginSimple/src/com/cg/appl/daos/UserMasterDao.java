package com.cg.appl.daos;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;

public interface UserMasterDao {
	
	User getUserDetials(String userName) throws UserException;

}
