//cityFilter
function findCities()
{
	//var state = document.getElementById("states").selectedIndex;
	var state = document.sampleEmpForm.State.selectedIndex;
	//alert(state);
	if(state == 0)
	{
		//alert(state+"inside");
		
		var city = new Option();
		city.value = "Mumbai";
		city.text = "Mumbai";
		document.sampleEmpForm.City.options[0]=city;
		
		var city2 = new Option();
		city2.value = "Pune";
		city2.text = "Pune";
		document.sampleEmpForm.City.options[1]=city2;
		
		var city3 = new Option();
		city3.value = "Nagpur";
		city3.text = "Nagpur";
		document.sampleEmpForm.City.options[2]=city3;
	}
	else if(state == 1)
	{
		var city = new Option();
		city.value = "Jaipur";
		city.text = "Jaipur";
		document.sampleEmpForm.City.options[0]=city;
		
		var city2 = new Option();
		city2.value = "Jodhpur";
		city2.text = "Jodhpur";
		document.sampleEmpForm.City.options[1]=city2;
		
		var city3 = new Option();
		city3.value = "Jaisalmer";
		city3.text = "Jaisalmer";
		document.sampleEmpForm.City.options[2]=city3;
	}
	else if(state == 2)
	{
		var city = new Option();
		city.value = "Panji";
		city.text = "Panji";
		document.sampleEmpForm.City.options[0]=city;
		
		var city2 = new Option();
		city2.value = "Dona Paula";
		city2.text = "Dona Paula";
		document.sampleEmpForm.City.options[1]=city2;
		
		var city3 = new Option();
		city3.value = "Caranzalem";
		city3.text = "Caranzalem";
		document.sampleEmpForm.City.options[2]=city3;
	}
}