function helloWorld()
{
	alert("inside hello !");
	return "Hello World !";
}