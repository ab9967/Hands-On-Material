findMovies()
{
	var lang = document.sampleEmpForm.lang.selectedIndex;
	//alert(state);
	if(lang == 0)
	{
}