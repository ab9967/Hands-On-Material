function valid(){
if(document.getElementById("chkBox").checked)
{
	alert("Multiple users / Systems Impacted");
}
}
function change()
{
	alert("sdhv");
	var fun= document.tktForm.funtns.selectedIndex;
	
	if(fun==0)
	{
		var no=new Option();
		no.value="Audio/Video/Web Presentation";
		no.text="Audio/Video/Web Presentation";
		document.tktForm.functions.options[0]=no;
		
		var no=new Option();
		no.value="Access Rights";
		no.text="Access Rights";
		document.tktForm.functions.options[1]=no;
		
		var no2=new Option();
		no.value="Asset Allocation";
		no.text="Asset Allocation";
		document.tktForm.functions.options[2]=no;
		
		var no=new Option();
		no.value="Network";
		no.text="Network";
		document.tktForm.functions.options[3]=no;
		
		var no=new Option();
		no.value="Printer";
		no.text="Printer";
		document.tktForm.functions.options[4]=no;
		
	}
	else if(fun==1)
	{
	    var no=new Option();
		no.value="Access Control";
		no.text="Access Control";
		document.tktForm.functions.options[0]=no;
		
		var no=new Option();
		no.value="Air Conditioning";
		no.text="Air Conditioning";
		document.tktForm.functions.options[1]=no;
		
		var no=new Option();
		no.value="Food and Cafeteria";
		no.text="Food and Cafeteria";
		document.tktForm.functions.options[2]=no;
		
		var no=new Option();
		no.value="CCTV and Fire Alarm";
		no.text="CCTV and Fire Alarm";
		document.tktForm.functions.options[3]=no;
		
		var no=new Option();
		no.value="House Keeping";
		no.text="House Keeping";
		document.tktForm.functions.options[4]=no;
		
	}
	else if(fun==2){
	    var no=new Option();
		no.value="Bus Transport";
		no.text="Bus Transport";
		document.tktForm.functions.options[0]=no;
		
		var no=new Option();
		no.value="Cab Transport";
		no.text="Cab Transport";
		document.tktForm.functions.options[1]=no;
		
		var no=new Option();
		no.value="Domestic Travel";
		no.text="Domestic Travel";
		document.tktForm.functions.options[2]=no;
		
		var no=new Option();
		no.value="International Travel";
		no.text="International Travel";
		document.tktForm.functions.options[3]=no;
		
	}