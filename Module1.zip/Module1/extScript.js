
var myWindow;
function bill()
{
	alert('Hello');
	
	
	var qt1= document.myBill.prod1.value;
	var qt2= document.myBill.prod2.value;
	var qt3= document.myBill.prod3.value;
	var qt4= document.myBill.prod4.value;
	var single_total;
	var total=0;
	var quantity_Ar= new Array(qt1, qt2, qt3, qt4);
	
	var mrp1= 20;
	var mrp2= 30;
	var mrp3= 40;
	var mrp4= 50;
	var mrp_Ar= new Array(mrp1, mrp2, mrp3, mrp4);
	
	var itm1= "Barbie doll";
	var itm2= "Calculator";
	var itm3= "Mobile phone";
	var itm4= "LG DVD";
	var itm_Ar= new Array(itm1, itm2, itm3, itm4);
	
	document.write("Printing Item array  -- "+itm_Ar+"<br>");
	document.write("<br>");
	document.write("Printing quantity array  -- "+quantity_Ar+"<br>");
	document.write("<br>");
	document.write("Printing price array  -- "+mrp_Ar+"<br>");
	document.write("<br>");
	
	
	if((qt1==null || qt1=="")&&(qt2==null || qt2=="")&&(qt3==null || qt3=="")&&(qt4==null || qt4==""))
	{
		alert('No item selected..pls enter quantity');
	}
	
	/*
	for(var i=0; i<quantity_Ar.length; i++)
	{
		document.write("Item "+i+" , Quantity : "+quantity_Ar[i]+" , MRP is:"+mrp_Ar[i]);
		document.write("<br>");
		single_total= quantity_Ar[i]*mrp_Ar[i];
		document.write("total for "+i+" is : "+single_total+"<br>");
		document.write("<br>");
		total=total+single_total;
	}

	document.write("Complete total is : "+total+"<br>");
	*/
	
	 myWindow = window.open("", "MsgWindow", "width=500,height=500");
	 
	  myWindow.document.write("<p align=center>INVOICE</p>");
	  
	  myWindow.document.write("<table border=1 align= center><tr> <td>PRODUCT</td> <td>QUANTITY</td> <td>PRICE</td> <td>TOTAL</td> </tr>");
	  
	  for(var i=0; i<quantity_Ar.length; i++)
	{
		if(quantity_Ar[i]!=null && quantity_Ar[i]!="")
		{
			single_total= quantity_Ar[i]*mrp_Ar[i];
			myWindow.document.write("<tr><td>"+itm_Ar[i]+" </td> <td>"+quantity_Ar[i] +"</td> <td>"+mrp_Ar[i]+"</td> <td>"+single_total+"</td> </tr>");
			total=total+single_total;
		}
	   
	
	}
	 myWindow.document.write("<tr><td>Total bill</td> <td></td> <td></td> <td>"+total+"</td></tr>");
	 myWindow.document.write("</table>");
}