var msg;
msg="<p><code>Actual script is in external script file called common.js</code></p>";
function addNos(headVar,bodyVar)
{
	document.write(msg);
	document.write("The sum of variables headVar and bodyVar is "+(headVar+bodyVar));
}