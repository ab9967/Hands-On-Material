
function makeOrder()
{
	
var c=0;

var total=new Array();
var totalprice=new Array();

var searchField=new Array();

		for(i=0;i<document.prodTable.qty.length;i++)
		{
		
		searchField[i]=document.prodTable.qty[i].value;
			
		}
	for(i=0;i<searchField.length;i++)
	{
	
		if((searchField[i]==0)||(searchField[i]==""))
		{
						c++;
		}
	}

		if(c==4)
		{
			alert('No item Selected.');
		}
		else
		{
	
	
		
var totalprice=0;
myWindow = open('','mywin','height=800,width=800,scrollbars=yes');

 myWindow.document.writeln("<html><head><title>Invoice slip</title></head><body>");
 myWindow.document.writeln("<center><h1>Invoice slip</h1><br /><br /><br />");
 myWindow.document.writeln("<table border='1'><tr>");
 
 myWindow.document.writeln("<td><b>Product</b></td>");
 myWindow.document.writeln("<td><b>Price</b></td>");
 myWindow.document.writeln("<td><b>Quantity</b></td>");
  myWindow.document.writeln("<td><b>Total</b></td>");
  
  for(var i=0;i<document.prodTable.qty.length;i++)
  {  
	  total[i]=(document.prodTable.price[i].value)*searchField[i];
 myWindow.document.writeln("</tr><tr><td>"+document.prodTable.item[i].value+"</td>");
  myWindow.document.writeln("<td>"+document.prodTable.price[i].value+"</td>");
 myWindow.document.writeln("<td>"+document.prodTable.qty[i].value+"</td>");
  
 myWindow.document.writeln("<td>"+total[i]+"</td>");

 totalprice=totalprice+total[i];

  }

  myWindow.document.writeln("</tr><tr><td><b>Total Price<b></td><td></td><td></td>");
myWindow.document.writeln("<td>"+totalprice+"</td>");
 myWindow.document.writeln("</tr></table></center></body></html>");
 myWindow.document.close();
		}
		}
	
