/************************************************************************************
*File 				:taxCalcScript.js
*Author 			:Capgemini
*Description 		:To calculate tax for given conditions
*Last date modified :10-02-2017
*Version 			:1.0
*Change Description :
************************************************************************************/
function getIncomeTax()
{
	var tax;
	var sal = document.taxForm.getElementsByName("sal");
		IF(sal<180000)
			tax = 0;
		ELSE IF(sal>=180000 AND sal<=300000)
			tax = sal*(0.10);
		ELSE IF(sal>=300001 AND sal<=500000)
			tax = sal*(0.20);
		ELSE IF(sal>500000)
			tax = sal*(0.30);
		END IF;
	
}