package com.cg.appl.test;

import com.cg.appl.entities.Author;
import com.cg.appl.exceptions.AuthorException;
import com.cg.appl.services.AuthorService;
import com.cg.appl.services.AuthorServiceImpl;

public class TestAuthorServices {

	public static void main(String[] args) throws AuthorException {
		
		AuthorService serviceRef = new AuthorServiceImpl();
		
		//insertion
		/*Author author = new Author();
		author.setAuthorId("1001");
		author.setFirstName("Tim");
		author.setMiddleName("James");
		author.setLastName("Sierra");
		author.setPhoneNo("9865327410");
		serviceRef.insertNewAuthor(author);
		
		Author author1 = new Author();
		author1.setAuthorId("1002");
		author1.setFirstName("Doug");
		author1.setMiddleName("Steve");
		author1.setLastName("Finn");
		author1.setPhoneNo("7895643210");
		serviceRef.insertNewAuthor(author1);
		
		Author author2 = new Author();
		author2.setAuthorId("1003");
		author2.setFirstName("Maverick");
		author2.setMiddleName("Dan");
		author2.setLastName("Brewster");
		author2.setPhoneNo("8795641230");
		serviceRef.insertNewAuthor(author2);*/
		
		
		//updation
		/*Author author = new Author();
		author.setAuthorId("1001");
		author.setFirstName("Tim");
		author.setMiddleName("Rocky");
		author.setLastName("Sierra");
		author.setPhoneNo("7965327410");
		serviceRef.updateAuthorDetails(author);*/
		
		//deletion
		String authorID = "1003";
		serviceRef.deleteAuthor(authorID);
	}

}
