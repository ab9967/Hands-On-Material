package com.cg.appl.services;

import com.cg.appl.entities.Author;
import com.cg.appl.exceptions.AuthorException;

public interface AuthorService
{
	public Author insertNewAuthor(Author obj) throws AuthorException;
	
	public boolean updateAuthorDetails(Author obj) throws AuthorException;
	
	public boolean deleteAuthor(String authorID) throws AuthorException;
}
