package com.cg.appl.services;

import com.cg.appl.daos.AuthorDao;
import com.cg.appl.daos.AuthorDaoImpl;
import com.cg.appl.entities.Author;
import com.cg.appl.exceptions.AuthorException;

public class AuthorServiceImpl implements AuthorService {

	AuthorDao daoRef;
	
	public AuthorServiceImpl() throws AuthorException {
		daoRef  = new AuthorDaoImpl();
	}

	@Override
	public Author insertNewAuthor(Author obj) throws AuthorException {
		
		return daoRef.insertNewAuthor(obj);
	}

	@Override
	public boolean updateAuthorDetails(Author obj) throws AuthorException {
		
		return daoRef.updateAuthorDetails(obj);
	}

	@Override
	public boolean deleteAuthor(String authorID) throws AuthorException {
		
		return daoRef.deleteAuthor(authorID);
	}

}
