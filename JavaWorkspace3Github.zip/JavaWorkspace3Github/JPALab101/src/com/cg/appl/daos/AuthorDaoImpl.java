package com.cg.appl.daos;

import javax.persistence.EntityManager;
import javax.persistence.RollbackException;

import com.cg.appl.entities.Author;
import com.cg.appl.exceptions.AuthorException;
import com.cg.appl.util.EntityManageUtil;

public class AuthorDaoImpl implements AuthorDao {

	private EntityManageUtil util;
	private EntityManager manager;
	
	public AuthorDaoImpl() throws AuthorException 
	{
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	@Override
	public Author insertNewAuthor(Author author) throws AuthorException {
		try {
			manager.getTransaction().begin();
			manager.persist(author); //inserts data in table and returns the author object
			manager.getTransaction().commit();
			if(author!=null)
				System.out.println("Author : "+author.getFirstName()+" data inserted.");
			
		} catch (RollbackException e) {
			throw new AuthorException("Column size or Constraint violated !!!"+e);
		}		
		return author;
	}

	private Author getAuthorInfo(String authorID) throws AuthorException {
		Author author = manager.find(Author.class, authorID); //returns null when authorID is wrong or not present in table
		if(author==null)
			{
				System.out.println("Author Not found ");
				throw new AuthorException("Wrong Author ID !!!");
			}		
		return author;
	}

	@Override
	public boolean updateAuthorDetails(Author obj) throws AuthorException {
		try
		{
			manager.getTransaction().begin();
			manager.merge(obj);
			manager.getTransaction().commit();
			
			System.out.println("Author : "+obj.getFirstName()+" data updated.");
			return true;
		}
		catch(RollbackException e)
		{
			throw new AuthorException("Author Updation Failure !!!"+e);
		}
		
	}

	@Override
	public boolean deleteAuthor(String authorID) throws AuthorException {
		try
		{
			manager.getTransaction().begin();
			Author author = this.getAuthorInfo(authorID);
			manager.remove(author);
			System.out.println("Author : "+author.getFirstName()+" data deleted.");
			manager.getTransaction().commit();		
			return true;
		}
		catch(RollbackException | AuthorException e)
		{
			throw new AuthorException("Author Deletion Failure !!!"+e);
		}
	}
	
	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}
	
}