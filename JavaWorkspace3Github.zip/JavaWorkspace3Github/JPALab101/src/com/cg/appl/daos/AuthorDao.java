package com.cg.appl.daos;

import com.cg.appl.entities.Author;
import com.cg.appl.exceptions.AuthorException;

public interface AuthorDao
{
	public Author insertNewAuthor(Author obj) throws AuthorException;
	
	public boolean updateAuthorDetails(Author obj) throws AuthorException;
	
	public boolean deleteAuthor(String authorID) throws AuthorException;
}
