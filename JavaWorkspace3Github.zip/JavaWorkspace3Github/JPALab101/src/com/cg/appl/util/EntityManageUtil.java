package com.cg.appl.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.cg.appl.exceptions.AuthorException;

public class EntityManageUtil
{
	private EntityManagerFactory factory;

	public EntityManageUtil() throws AuthorException {
		super();
		try {
			factory = Persistence.createEntityManagerFactory("JPA-PU");
			
			
		} catch (PersistenceException e) {
			
			//e.printStackTrace();
			throw new AuthorException("Creation of Persistence unit failed !!!"+e);
		}
		//factory creation is time consuming task
	}
	
	public EntityManager getManager()
	{
		return factory.createEntityManager();
	}
	
	public void closeFactory()
	{
		if(factory != null)
		{
			factory.close();
		}
	}

	@Override
	protected void finalize() throws Throwable {
		this.closeFactory();
		
		super.finalize();
	}
	
	
}
