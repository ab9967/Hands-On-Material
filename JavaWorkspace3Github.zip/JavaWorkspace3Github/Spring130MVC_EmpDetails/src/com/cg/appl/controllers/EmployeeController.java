package com.cg.appl.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


//htttp://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class EmployeeController
{
		//give login .jsp
		@RequestMapping("/showEmpForm.do")
		public ModelAndView showEmpForm()
		{
			System.out.println("sdjfbaksdbfkd");
			ModelAndView model = new ModelAndView("enterEmployee");
			return model;
		}
		
		//fetching empID from form
		@RequestMapping("/getEmployee.do") 	//here input parameter must be mapped to textfields in login.jsp file form
		public void authenticate(@RequestParam String eID)
		{
			System.out.println(eID);
			
			/*ModelAndView model = new ModelAndView();
			
			if(userName.equals("asd")&&password.equals("qwe"))
			{
				model.setViewName("success");
				model.addObject("userName", userName);
			}
			else
			{
				model.addObject("errMsg", "Login Failed please Re-Enter");
				model.setViewName("login");
			}
			return model;*/
		}
}
