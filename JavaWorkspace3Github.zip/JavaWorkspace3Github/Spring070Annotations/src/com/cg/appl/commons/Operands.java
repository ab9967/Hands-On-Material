package com.cg.appl.commons;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("operands")
public class Operands
{
		@Value("10") int val1;
						
		public int getVal1() {
			return val1;
		}
		public void setVal1(int val1) {
			this.val1 = val1;
		}
		
		@Value("20") int val2;	
		public int getVal2() {
			return val2;
		}
		public void setVal2(int val2) {
			this.val2 = val2;
		}

		public int calcVal3()
		{
			return 30;
		}
}
