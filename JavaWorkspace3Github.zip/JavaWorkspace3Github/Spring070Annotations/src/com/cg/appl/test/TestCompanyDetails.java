package com.cg.appl.test;

import org.springframework.context.ApplicationContext;

import com.cg.appl.commons.Address;
import com.cg.appl.commons.CompanyDetails;
import com.cg.appl.util.SpringUtil;

public class TestCompanyDetails {

	public static void main(String[] args) {
		//get application context
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		
		//execute getBean method
		CompanyDetails details = (CompanyDetails)ctx.getBean("companyDetails");
		System.out.println("Name : "+details.getCompanyName());
		System.out.println("Motto : "+details.getCompanyMotto());
		System.out.println("Rank : "+details.getNiftyRank());
		System.out.println("Address : "+details.getAddr());
		System.out.println(details.getDirectors());
		
		//System.out.println(details);
		
		/*Address address = ctx.getBean("address",Address.class);
		System.out.println("Line 1 : "+address.getLine1());
		System.out.println("Line 2 : "+address.getLine2());
		System.out.println("Area : "+address.getArea());*/
		//System.out.println(details);
	}

}
