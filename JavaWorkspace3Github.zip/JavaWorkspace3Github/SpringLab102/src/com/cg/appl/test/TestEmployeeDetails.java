package com.cg.appl.test;

import org.springframework.context.ApplicationContext;

import com.cg.appl.entities.Employee;
import com.cg.appl.util.SpringUtil;

public class TestEmployeeDetails {

	public static void main(String[] args) {
		//get application context
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		
		//execute getBean method
		Employee emp = ctx.getBean("emp",Employee.class);
		System.out.println("Employee Details");
		System.out.println("-------------------------------");
		System.out.println("Employee ID : "+emp.getEmployeeId());
		System.out.println("Employee Name : "+emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee BU : "+emp.getBusinessUnit());
		System.out.println("Employee Age : " +emp.getAge());
		System.out.println(emp.getSbu());
	}

}
