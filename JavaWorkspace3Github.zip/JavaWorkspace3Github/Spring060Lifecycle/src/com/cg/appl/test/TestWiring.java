package com.cg.appl.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.cg.appl.daos.EntityDao;
import com.cg.appl.util.SpringUtil;

public class TestWiring
{

	public static void main(String[] args)
	{
		System.out.println("1");
		SpringUtil util = new SpringUtil();
		System.out.println("2");
		ConfigurableApplicationContext ctx = (ConfigurableApplicationContext) util.getSpringContext();
		System.out.println("3");
		EntityDao dao = ctx.getBean("entityDao",EntityDao.class);
		System.out.println("4");
		System.out.println(dao.hashCode());
		System.out.println("5");
		dao.getConnection();
		ctx.close();
	}

}
