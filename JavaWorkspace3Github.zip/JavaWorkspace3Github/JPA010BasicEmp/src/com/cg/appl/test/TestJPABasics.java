package com.cg.appl.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.appl.entities.Emp;

public class TestJPABasics {

	public static void main(String[] args) {
		
//		1. create entity manager factory >> makes data source, connection pool, Cache-2 ready
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		
//		2. create entity manager >> makes Cache-1 ready and other low overhead tasks like dialect, etc. ready
		EntityManager manager = factory.createEntityManager();
		
//		3. Get a record
//		Emp empRef = manager.find(Emp.class, 7788);
//		System.out.println(empRef);
//		fetching all records
		Query qry= manager.createQuery("Select e from employee e where empSal>=3000");
		@SuppressWarnings("unchecked")
		List<Emp> empList = qry.getResultList();
		for(Emp index:empList)
		{
			System.out.println(index);
		}
		
//		4. close resources
		manager.close();
		factory.close();
	}
}
/*
 *  org.hibernate.hql.ast.QuerySyntaxException: emp is not mapped [Select e from emp e]
 *  >> table name not proper, using initCap for tableName might work
 *   org.hibernate.PropertyAccessException: Null value was assigned to a property of primitive type setter of com.cg.appl.entities.Emp.empSal
 *  >>Some attribute value might be null in oracle table in such case use wrapper class data types
 * */