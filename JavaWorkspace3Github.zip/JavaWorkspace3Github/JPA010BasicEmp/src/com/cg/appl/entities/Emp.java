package com.cg.appl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity(name="employee")
//class Name OR entity name is implicit table name in case not specified
@Table(name="EMP")
public class Emp implements Serializable 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int empNo;
	private String empNm;
	private float empSal;
	
	//annotation used for setting identifier for JPA
	//ignoring @Id will give exception : no identifier specified for entity
	@Id
	//@Column(name="EMPNO")
	public int getEmpNo() {			//empNo
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	@Column(name="ENAME")
	public String getEmpNm() {				//empNm
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	@Column(name="SAL")
	public float getEmpSal() {					//empSal
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + "]";
	}	
}
/*ORA-00904: "EMP0_"."EMPNM": invalid identifier
 * column not found
 * ORA_00492: table or view does not exist
 * */
