/****************************************************************
*File 				:EmpService.java
*Author 			:Capgemini	
*Description 		:Service Interface of Employee Directory Application
*Last date modified :31-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.appl.services;

import java.util.List;

import javax.persistence.RollbackException;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

public interface EmpServices
{
	//method to get all employees
	List<Employee>	getAllEmployees() throws EmpException;
	
	//method to insert new employee
	Employee insertNewEmployee(Employee emp) throws EmpException, RollbackException;
}
