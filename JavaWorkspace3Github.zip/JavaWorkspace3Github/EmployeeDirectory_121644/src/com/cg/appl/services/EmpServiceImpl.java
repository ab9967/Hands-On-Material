/****************************************************************
*File 				:EmpServiceImpl.java
*Author 			:Capgemini	
*Description 		:Service class of Employee Directory Application
*Last date modified :31-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

@Service("EmpService")
@Transactional
public class EmpServiceImpl implements EmpServices {

	private EmpDao dao;
	
	@Resource(name="EmpDao")
	public void setEmpdao(EmpDao dao)
	{
		this.dao = dao;
	}
	
	@Override
	public List<Employee> getAllEmployees() throws EmpException {
		
		return dao.getAllEmployees();
	}

	@Override
	public Employee insertNewEmployee(Employee emp) throws EmpException {
		
		return dao.insertNewEmployee(emp);
	}

}