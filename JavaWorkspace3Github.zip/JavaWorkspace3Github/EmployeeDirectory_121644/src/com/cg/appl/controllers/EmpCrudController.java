/****************************************************************
*File 				:EmpCrudController.java
*Author 			:Capgemini	
*Description 		:Controller of Employee Directory Application
*Last date modified :31-03-2017
*Version 			:1.0
*****************************************************************/
package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;

@Controller
public class EmpCrudController
{
	private EmpServices services;
	List<String> designationNames;
	
	@PostConstruct
	public void intialize()
	{
		//List for designation field in add New Employee form
		designationNames = new ArrayList<>();
		designationNames.add("Software Engineer");
		designationNames.add("Senior Software Engineer");
		designationNames.add("Team Lead");
		designationNames.add("Manager");
	}
	
		//service injection
		@Resource(name="EmpService")
		public void setEmployeeServices(EmpServices services)
		{
			this.services  = services;
		}
		
		//method for loading home page
		@RequestMapping("/welcome.do")
		public ModelAndView getWelcomePage()
		{
			ModelAndView model = new ModelAndView("welcome");
			return model;
		}	
		
		//method for loading all Employee Details
		@RequestMapping("/listAllEmployees.do")
		public ModelAndView listAllEmployees()
		{
			
			ModelAndView model = null;
			try 
			{				
				List<Employee> empList = services.getAllEmployees();
				model = new ModelAndView("showAllEmployee");
				model.addObject("empList", empList);
			}
			catch (EmpException e)
			{
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());				
			}			
			return model;
		}
		
		//method for loading add new employee form
		@RequestMapping("/addEmployeeForm.do")
		public ModelAndView getAddEmployeeForm()
		{
			ModelAndView model = new ModelAndView("addNewEmployee");
			model.addObject("employee", new Employee());
			
			//adding designation names list into model
			model.addObject("designationNames", designationNames);
			
			return model;
		}
		
		//method for fetching values from form and applying validations to form
		@RequestMapping("/insertEmpDetails.do")
		public ModelAndView insertEmpDetails(@ModelAttribute("employee") @Valid Employee employee, BindingResult result)
		{
			ModelAndView model  = new ModelAndView();
			
			if(result.hasErrors())
			{
				model.addObject("employee");
				model.setViewName("addNewEmployee");
				model.addObject("designationNames", designationNames);
				return model;
			}
			else
			{			
			try {
						Employee empResponse = services.insertNewEmployee(employee);
						model.setViewName("successInsert");
						model.addObject("successMsg","Employee added successfully and the employee code is "+empResponse.getEmpCode());
						System.out.println(empResponse);
						
				} catch (EmpException e) {
					model.addObject("errMsg", "Unable to insert Employee : "+employee.getEmpCode());
					model.setViewName("addNewEmployee");
				}
				return model;
			}
		}
			
}