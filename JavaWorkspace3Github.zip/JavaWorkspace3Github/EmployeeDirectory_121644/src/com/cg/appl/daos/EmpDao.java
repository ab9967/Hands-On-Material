/****************************************************************
*File 				:EmpDao.java
*Author 			:Capgemini	
*Description 		:DAO Interface of Application
*Last date modified :31-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.appl.daos;

import java.util.List;

import javax.persistence.RollbackException;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao
{
		//method to get all employees
		List<Employee>	getAllEmployees() throws EmpException;
		
		//method to insert new employee
		Employee insertNewEmployee(Employee emp) throws EmpException, RollbackException;
		
}
