/****************************************************************
*File 				:EmpDaoImpl.java
*Author 			:Capgemini	
*Description 		:DAO class of Employee Directory Application
*Last date modified :31-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

@Repository("EmpDao")
public class EmpDaoImpl implements EmpDao {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public List<Employee> getAllEmployees() throws EmpException {
		
		//EntityManager manager = factory.createEntityManager();
		Query	query = manager.createNamedQuery("qryAllEmps", Employee.class);
			
		return query.getResultList();
	}

	@Override
	public Employee insertNewEmployee(Employee emp) throws EmpException, RollbackException {
		
		manager.persist(emp);
		
		return emp;
	}
}