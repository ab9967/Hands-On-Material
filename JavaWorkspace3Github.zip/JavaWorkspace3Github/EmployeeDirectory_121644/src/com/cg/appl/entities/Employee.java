/****************************************************************
*File 				:Employee.java
*Author 			:Capgemini	
*Description 		:Entity class of Employee Directory Application
*Last date modified :31-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.appl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="employee")
@Table(name="EMPLOYEE")

@NamedQueries
(
	{
		//this is query Name and not method name
		@NamedQuery(name="qryAllEmps", query="select e from employee e")
	}
)

@SequenceGenerator(name="emp_generate", sequenceName="hibernate_sequence", allocationSize=1, initialValue=1001)

public class Employee implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int empCode;
	private String empName;
	private String empGender;
	private String designation;
	private String email;
	private String empPhoneNo;
	
	@Id
	@Column(name="EMPLOYEE_CODE")
	@GeneratedValue(generator="emp_generate", strategy=GenerationType.SEQUENCE)
	public int getEmpCode() {
		return empCode;
	}
	public void setEmpCode(int empCode) {
		this.empCode = empCode;
	}
	
	
	@Column(name="EMPLOYEE_NAME")
	@NotEmpty(message="Name is mandatory")
	@Size(min=1,max=40,message="Name must be less than 40 characters !!!")
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	@Column(name="EMPLOYEE_GENDER")
	@NotEmpty(message="Gender is mandatory")
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	
	@Column(name="DESIGNATION_NAME")
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	@Column(name="EMPLOYEE_EMAIL")
	@NotEmpty(message="Email is mandatory")
	@Email(message="Invalid Email Format !!!")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name="EMPLOYEE_PHONE")
	@NotEmpty(message="Phone Number is mandatory")
	@Length(max=10,min=10,message="Phone number is not valid. It should be 10 digit Long")
	@Pattern(regexp="^[1-9]{10}$",message="Phone Number should have Digits only !!!")
	public String getEmpPhoneNo() {
		return empPhoneNo;
	}
	public void setEmpPhoneNo(String empPhoneNo) {
		this.empPhoneNo = empPhoneNo;
	}
	
	
	@Override
	public String toString() {
		return "Employee [empCode=" + empCode + ", empName=" + empName
				+ ", empGender=" + empGender + ", designation=" + designation
				+ ", email=" + email + ", empPhoneNo=" + empPhoneNo + "]";
	}
	
}
