package com.cg.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.EntityManageUtil;

public class EmpDaoImpl implements EmpDao
{
	private EntityManageUtil util;
	private EntityManager manager;
	
	public EmpDaoImpl() throws EmpException
	{
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	
	private Emp getEmpDetails(int empNo) throws EmpException {
		Emp emp = manager.find(Emp.class, empNo); //returns null when empNo is wrong or not present in table
		if(emp==null)
			{
				System.out.println("Employee Not found ");
				throw new EmpException("Wrong EmpNo !!!");
			}
		
		return emp;
	}	
	
	@Override
	public Emp getEmpDetailsSafe(int empNo) throws EmpException {
		Emp emp = manager.find(Emp.class, empNo); //returns null when empNo is wrong or not present in table
		if(emp==null)
			{
				System.out.println("Employee Not found ");
				throw new EmpException("Wrong EmpNo !!!");
			}
		//next line removes emp object from entity manager
		//i.e. it changes state of object from persistent state to transient state
		manager.detach(emp);
		return emp;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		try {
			//Query qry = manager.createQuery("select e from employee e");//JPAQL
			//here employee is entity name mentioned in entity class with annotation
			
			Query qry = manager.createNamedQuery("qryAllEmps");//namedQuery
			@SuppressWarnings("unchecked")
			List<Emp> empList = qry.getResultList();
			
			return empList;
		} catch (Exception e) {
			throw new EmpException("Improper query fabrication !!!"+e);
		}
	}	
	
	@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			manager.persist(emp); //inserts data in table and returns the emp object
			manager.getTransaction().commit();
			
			
		} catch (RollbackException e) {
			throw new EmpException("Column size or Constraint violated !!!"+e);
		}
		
		return emp;
	}
	
	/*@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		try {
			manager.getTransaction().begin();
			
			Emp emp = this.getEmpDetails(empNo);
			//updation can be done simply using setter method
			//here the object to be updated must be persistent state i.e. first we fetch data by find() method so that we can work with
			//					persistent object
			emp.setEmpNm(newName);
			
			manager.getTransaction().commit();		
			return true;
		} catch (RollbackException e) {
			
			throw new EmpException("Name updation failure !!!"+e);
		}
	}*/
	
	@Override
	public boolean updateEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			
			manager.merge(emp);
			/*Emp emp2 = this.getEmpDetails(emp.getEmpNo());*/
			//updation can be done simply using setter method
			//here the object to be updated must be persistent state i.e. first we fetch data by find() method so that we can work with
			//					persistent object
			/*emp2.setEmpNo(emp.getEmpNo());
			emp2.setEmpNm(emp.getEmpNm());
			emp2.setEmpSal(emp.getEmpSal());*/
			
			manager.getTransaction().commit();		
			return true;
		} catch (RollbackException e) {
			
			throw new EmpException("Employee updation failure !!!"+e);
		}
	}
	
	@Override
	public boolean delete(int empNo) throws EmpException {
		try {
			manager.getTransaction().begin();
			Emp emp = this.getEmpDetails(empNo);
			manager.remove(emp);
			
			manager.getTransaction().commit();		
			return true;
		} catch (RollbackException|EmpException e) {
			
			throw new EmpException("Employee deletion failure !!!"+e);
		}
		//return false;
	}
	
	@Override
	public List<Emp> getEmpsOnSal(float from, float to) throws EmpException {
		
		/*String qryStr = "Select e from employee e where empSal between ? AND ?";*/
		/*String qryStr = "Select e from employee e where empSal between :from AND :to";*/
		/*TypedQuery<Emp> qry = manager.createQuery(qryStr, Emp.class);*/
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsOnSal", Emp.class);
		/*qry.setParameter(1, from);
		qry.setParameter(2, to);*/
		qry.setParameter("from", from);
		qry.setParameter("to", to);
		return qry.getResultList();
		
	}	
	
	@Override
	public List<Emp> getEmpsForCommision() throws EmpException {
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsWithComm", Emp.class);
			
		return qry.getResultList();
	}
	
	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}
}