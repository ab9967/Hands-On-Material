package com.cg.appl.test;

//import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpService;
import com.cg.appl.services.EmpServiceImpl;

public class TestEmpServices {

	public static void main(String[] args)
	{
			try {
				EmpService services = new EmpServiceImpl();
				
				/*Emp emp = services.getEmpDetails(7788);
				System.out.println(emp);*/
				
/*				System.out.println("#############################################################");
				
				List<Emp> empList = services.getEmpList();				
				for(Emp index:empList)
				{
					System.out.println(index);
				}
*/								
				//services.admitNewEmp(emp);
				
				/*Emp emp1 = new Emp();
				emp1.setEmpNo(7989);
				emp1.setEmpNm("Kevin");
				emp1.setEmpSal(40000f);
				
				System.out.println(services.admitNewEmp(emp1));
				
				System.out.println(services.getEmpDetails(7989));*/
				//###################################################################################
				
				/*System.out.println(services.updateName(7876, "Gary"));
				System.out.println(services.getEmpDetails(7876));*/
				
				/*System.out.println(services.getEmpDetails(7989));
				
				Emp emp = new Emp();
				emp.setEmpNo(7989);
				emp.setEmpNm("TIm");
				emp.setEmpSal(4000f);
				
				if(services.updateEmp(emp))
					System.out.println(services.getEmpDetails(7989));
				else
					System.out.println("Not updated !!!");*/
				
				/*System.out.println(services.getEmpDetails(7987));
				
				services.delete(7987);
				*/
				//System.out.println(services.getEmpDetails(7788));
				
				
			} catch (EmpException e) {				
				e.printStackTrace();
			}
	}	
}