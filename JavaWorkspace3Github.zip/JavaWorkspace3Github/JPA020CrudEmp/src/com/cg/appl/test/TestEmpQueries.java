package com.cg.appl.test;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpService;
import com.cg.appl.services.EmpServiceImpl;

public class TestEmpQueries {

	public static void main(String[] args) {
		try {
			EmpService services = new EmpServiceImpl();
			
			/*List<Emp> empList = services.getEmpsOnSal(2000, 5000);
			
			//empList.forEach(System:);
			System.out.println("Named Query 1 Result : ");
			for(Emp index:empList)
				System.out.println(index);
			
			empList.clear();
			System.out.println("Named Query 2 Result : ");
			empList = services.getEmpList();
			
			for(Emp index:empList)
				System.out.println(index);*/
			
			/*Emp emp = new Emp();
			emp.setEmpNm("Steve");
			emp.setEmpSal(5000f);
			
			Emp emp1 = services.admitNewEmp(emp);
			System.out.println("After insertion");
			System.out.println(emp1);*/
			
			System.out.println("Employee's with Commision : ");
			
			List<Emp> empList = services.getEmpsForCommision();
			for(Emp index:empList)
			{
				System.out.println(index);
			}
		} catch (EmpException e) {
			
			e.printStackTrace();
		}
	}

}
