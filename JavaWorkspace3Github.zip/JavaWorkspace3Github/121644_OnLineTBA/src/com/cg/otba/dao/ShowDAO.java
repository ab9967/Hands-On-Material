/****************************************************************
*File 				: ShowDAO.java
*Author 			:Capgemini	
*Description 		: DAO Layer File
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;
import com.cg.otba.exceptions.TicketBookingException;

public class ShowDAO implements IShowDAO {

	private com.cg.otba.util.JndiUtil utils = null;
	Connection conn = null;
	PreparedStatement pst = null;
		
	public ShowDAO() {
		super();
		try {
			utils = new com.cg.otba.util.JndiUtil();
			
			
		} catch (TicketBookingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in util generation !!!" +e);
		}
	}

	@Override
	public List<Show> getAllShows() {
		
		ResultSet rs = null;
		List<Show> shoList = new ArrayList<Show>();
		String query = "SELECT * FROM ShowDetails"; 
		
		try {
			conn = utils.getConnection();
			pst = conn.prepareStatement(query);
						
			rs = pst.executeQuery();
			
			while(rs.next())
			{
				Show tempSho = new Show();
				
				tempSho.setShowID(rs.getString("ShowId"));
				tempSho.setShowName(rs.getString("ShowName"));
				tempSho.setLocation(rs.getString("Location"));
				
				Date tempDate = rs.getDate("ShowDate");
				LocalDate tempLDate = tempDate.toLocalDate();
				tempSho.setShowDate(tempLDate);
				
				tempSho.setAvSeats(rs.getInt("AvSeats"));
				tempSho.setPriceTicket(rs.getDouble("PriceTicket"));
				
				shoList.add(tempSho);
				System.out.println(tempSho.toString());
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in fetching show Data !!!" +e);
		}
		
		return shoList;
	}

	@Override
	public boolean[] isSold() {
		boolean[] flag = new boolean[5];
		int i=0;
		int temp = 0;
		ResultSet rs = null;
		String query = "SELECT AvSeats FROM ShowDetails"; 
		
		
			try {
				conn = utils.getConnection();
				pst = conn.prepareStatement(query);
				
				rs = pst.executeQuery();
				
				while(rs.next())
				{
					temp = rs.getInt("AvSeats");
					if(temp <= 0)
					{
						flag[i] = true;
					}
					i++;
				}
				return flag;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("Exception in fetching available seats !!!"+e);
			}
			
	
		return null;
	}

	@Override
	public boolean bookTicket(Customer customer , String showName) {
		// update av seat count 
		String query = "UPDATE ShowDetails SET AvSeats = AvSeats - ? WHERE ShowName = ?";
		int count =0;
		try {
			conn = utils.getConnection();
			pst = conn.prepareStatement(query);
			pst.setInt(1, customer.getNoOfSeats());
			pst.setString(2, showName);
			
			count = pst.executeUpdate();
			
			if(count>0)
			{
				System.out.println(count + "row Updated");
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in updating Av. Seat Count !!!"+e);
		}
		
		return false;
	}

	@Override
	public Show getShowDetails(String sID) {
		Show tempSho = new Show();
		
		ResultSet rs = null;
		
		String query = "SELECT * FROM ShowDetails WHERE ShowId = ?"; 
		
		try {
			conn = utils.getConnection();
			pst = conn.prepareStatement(query);
			pst.setString(1, sID);
			rs = pst.executeQuery();
			
			if(rs.next())
			{
				tempSho.setShowID(rs.getString("ShowId"));
				tempSho.setShowName(rs.getString("ShowName"));
				tempSho.setLocation(rs.getString("Location"));
				
				Date tempDate = rs.getDate("ShowDate");
				LocalDate tempLDate = tempDate.toLocalDate();
				tempSho.setShowDate(tempLDate);
				
				tempSho.setAvSeats(rs.getInt("AvSeats"));
				tempSho.setPriceTicket(rs.getDouble("PriceTicket"));
				
				return tempSho;
			}
			else
			{
				return null;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in fetching show Data !!!" +e);
		}
		
		return null;
	}

	

}
