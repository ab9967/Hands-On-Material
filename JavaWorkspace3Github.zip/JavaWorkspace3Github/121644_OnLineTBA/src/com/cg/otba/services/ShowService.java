/****************************************************************
*File 				: ShowService.java
*Author 			:Capgemini	
*Description 		: Service Layer File
*Last date modified :14-03-2017
*Version 			:1.0
*****************************************************************/

package com.cg.otba.services;

import java.util.List;

import com.cg.otba.dao.IShowDAO;
import com.cg.otba.dao.ShowDAO;
import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;

public class ShowService implements IShowService {

	IShowDAO daoRef;
	
	public ShowService() {
		super();
		
		daoRef = new ShowDAO();
		
	}

	@Override
	public List<Show> getAllShows() {
		
		return daoRef.getAllShows();
	}

	@Override
	public boolean[] isSold() {
		
		return daoRef.isSold();
	}

	@Override
	public boolean bookTicket(Customer customer , String showName) {
		
		return daoRef.bookTicket(customer, showName);
	}

	@Override
	public Show getShowDetails(String sID) {
		
		return daoRef.getShowDetails(sID);
	}

}
