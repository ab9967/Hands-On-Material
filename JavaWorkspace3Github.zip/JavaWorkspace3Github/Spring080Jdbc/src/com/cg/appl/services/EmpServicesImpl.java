package com.cg.appl.services;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

//@Component("empService")
@Service("empService")
public class EmpServicesImpl implements EmpServices
{
	private EmpDao dao;
	
	public EmpServicesImpl()
	{
		System.out.println("In constructor from EmpServicesImpl");
	}

	@Override
	public Emp getEmpDetails(int empNo) throws EmpException {
		System.out.println("In getEmpDetails() service");
		return dao.getEmpDetails(empNo);
	}

	/*@Autowired
	@Qualifier*/
	@Resource(name="empDao")
	//above annotation registers bean empDao
	public void setDao(EmpDao dao) {
		System.out.println("In setDao()");
		this.dao = dao;		//dao
	}	
}