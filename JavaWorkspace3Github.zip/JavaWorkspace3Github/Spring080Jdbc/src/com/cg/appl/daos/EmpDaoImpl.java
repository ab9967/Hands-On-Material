package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

/*
 * Component : for every class
 * Service : for service classes
 * Repository : for dao classes
 * Controller : For controller classes of Spring MVC
 * RestController : To declare controller classes for publishing REST services
 * 
 * */


//@Component("empDao")
//@Repository("empDao")
@Scope("singleton")
public class EmpDaoImpl implements EmpDao
{

	private DataSource dataSrc;
	
	public EmpDaoImpl()
	{
		System.out.println("In EmpDaoImpl() constructor in Dao");
	}	
	
	@Resource(name="dataSource")
	public void setDataSource(DataSource dataSource)
	{
		this.dataSrc = dataSource;
	}
	
	@Override
	public Emp getEmpDetails(int empNo) throws EmpException {
		System.out.println("in getEmpDetails() of dao impl");	
		Connection connect=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String query = "select * from emp where EMPNO=?";
		
		try {
			connect = dataSrc.getConnection();
			pstmt = connect.prepareStatement(query);
			pstmt.setInt(1, empNo);
			rs = pstmt.executeQuery();
			
			if (rs.next())
			{
				Emp emp = new Emp();
				emp.setEmpNo(rs.getInt("EMPNO"));
				emp.setEmpNm(rs.getString("ENAME"));
				emp.setEmpSal(rs.getFloat("SAL"));
				emp.setComm(rs.getFloat("COMM"));
				
				return emp;
			}
			else
			{
				return null;
			}
			
		} catch (SQLException e) {
			throw new EmpException("Problem in DB Handling",e);			
		} finally
		{
			try {
				if(rs!=null)
				{
					rs.close();
				}
				if(pstmt!=null)
				{
					pstmt.close();
				}
				if(connect!=null)
				{
					connect.close();
				}
			} catch (SQLException e) {
				throw new EmpException("Problem in DB Closing",e);
			}
		}
	}
}