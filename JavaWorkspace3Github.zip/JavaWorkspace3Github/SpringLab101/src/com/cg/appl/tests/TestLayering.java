package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.entities.Employee;
import com.cg.appl.util.SpringUtil;

public class TestLayering {

	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();		//creates multiple references of all classes in context table
		ApplicationContext ctx = util.getSpringContext(); 		//gives context ref to ctx object
		
		
		Employee emp = ctx.getBean("emp", Employee.class);
		System.out.println("Employee Details");
		System.out.println("-------------------------------");
		System.out.println("Employee ID : "+emp.getEmployeeId());
		System.out.println("Employee Name : "+emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee BU : "+emp.getBusinessUnit());
		System.out.println("Employee Age : " +emp.getAge());
	}
}