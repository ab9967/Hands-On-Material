package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Service("EmpService")
@Transactional
public class EmpServiceImpl implements EmpServices {

	private EmpDao dao;
	
	@Resource(name="EmpDao")
	public void setTraineedao(EmpDao dao)
	{
		this.dao = dao;
	}
	
	@Override
	public Emp getEmpDetails(int empId) throws EmpException
	{
		
		return dao.getEmpDetails(empId);
	}

	@Override
	public List<Emp> getAllEmps() throws EmpException {
		
		return dao.getAllEmps();
	}

	//container managed transactions {}
	//@Transactional 	//implicitly manages transactions of insertion internally
	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException {
		
		return dao.insertNewEmp(emp);
	}

	@Override
	public Emp deleteEmpDetails(int empNo) throws EmpException {
		
		return dao.deleteEmpDetails(empNo);
	}

	@Override
	public Emp updateEmpDetails(Emp emp)
			throws EmpException {
		
		return dao.updateEmpDetails(emp);
	}
	
	
	
}
//