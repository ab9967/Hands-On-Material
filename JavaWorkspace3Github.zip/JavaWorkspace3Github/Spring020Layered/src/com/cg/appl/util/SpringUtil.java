package com.cg.appl.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringUtil
{
	private ApplicationContext context;

	public SpringUtil() {
		context = new ClassPathXmlApplicationContext("companyHr.xml");		
	}
	
	public ApplicationContext getSpringContext()
	{
		return context;		
	}
}
/*Exception in thread "main" org.springframework.beans.factory.BeanDefinitionStoreException: IOException parsing
XML document from class path resource [companyH.xml]; nested
exception is java.io.FileNotFoundException: class path resource [companyH.xml] cannot be opened because it does not exist
is raised when the xml file name is mistaken or xml file is in wrong folder
*/

/*when #Cannot find class [com.cg.appl.daos.EmpDaoImpl1] for bean with name 'empDao' defined in class path resource
 * [companyHr.xml]; nested exception is
 * java.lang.ClassNotFoundException: com.cg.appl.daos.EmpDaoImpl1# is raised
 * check for package/class names in xml file and their recpective names in src*/

/*when #No bean named 'dbUtil1' is defined# exception is raised check in xml property names and ref*/