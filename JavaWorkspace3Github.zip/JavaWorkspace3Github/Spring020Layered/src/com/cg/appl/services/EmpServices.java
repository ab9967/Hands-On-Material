package com.cg.appl.services;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpServices {

	Emp getEmpDetails() throws EmpException;
	
}
