package com.cg.appl.daos;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao
{
		Emp getEmpDetails() throws EmpException;
}