package com.cg.appl.daos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.EntityManageUtil;

/*
 * Component : for every class
 * Service : for service classes
 * Repository : for dao classes
 * Controller : For controller classes of Spring MVC
 * RestController : To declare controller classes for publishing REST services
 * 
 * */


//@Component("empDao")
@Repository("empDao")
public class EmpDaoImpl implements EmpDao
{
	
	private EntityManageUtil util;
	public EmpDaoImpl()
	{
		System.out.println("In DaoImpl constructor !!!");
	}	
	
	@Override
	public Emp getEmpDetails() throws EmpException {
		System.out.println("in getEmpDetails of dao impl");	
		return null;
	}

	public EntityManageUtil getUtil() {
		return util;
	}
	
	//@Autowired			//autowiring by type
	@Qualifier("dbUtil")  	//autowiring by name
	public void setUtil(EntityManageUtil util) {		//util
		System.out.println("In setUtil()");
		this.util = util;
	}
}