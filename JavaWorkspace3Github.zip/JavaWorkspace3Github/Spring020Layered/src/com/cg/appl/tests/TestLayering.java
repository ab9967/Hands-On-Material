package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.util.SpringUtil;

public class TestLayering {

	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();		//creates multiple references of all classes in context table
		ApplicationContext ctx = util.getSpringContext(); 		//gives context ref to ctx object
		
		EmpServices services = ctx.getBean("empService",EmpServices.class);
		
		try {
			services.getEmpDetails();			
		} catch (EmpException e) {			
			e.printStackTrace();
		}
	}
}