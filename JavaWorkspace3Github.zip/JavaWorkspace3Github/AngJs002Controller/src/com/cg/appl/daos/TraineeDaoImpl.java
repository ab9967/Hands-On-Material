package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao {

	private EntityManagerFactory factory;
	
	@Resource(name="entityMFactory")
	public void setEntityMFactory(EntityManagerFactory factory)
	{
		this.factory = factory;
	}
	
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		EntityManager manager = factory.createEntityManager();
		
		Trainee trainee = manager.find(Trainee.class, traineeId);		
		return trainee;
	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		
		String queryStr = "select t from trainee t";
		EntityManager manager = factory.createEntityManager();
		Query	query = manager.createQuery(queryStr, Trainee.class);
			
		return query.getResultList();
	}

	@Override
	public Trainee insertNewTrainee(Trainee trainee) throws TraineeException {
		
		EntityManager manager = factory.createEntityManager();
		
		//programatic trasaction management
		try {
			manager.getTransaction().begin();
			manager.persist(trainee); //inserts data in table and returns the trainee object
			manager.getTransaction().commit();
			
		} catch (RollbackException e) {
			manager.getTransaction().rollback();
			throw new TraineeException("Record not commited",e);
		}
		
		if(trainee!=null)
		{
			System.out.println("Trainee : "+trainee.getTraineeName()+" inserted.");
		}
		
		return trainee;
	}

	@Override
	public boolean deleteTraineeDetails(int traineeId) throws TraineeException {
		
		EntityManager manager = factory.createEntityManager();
		
		try {
			manager.getTransaction().begin();
			
			Trainee trainee = manager.find(Trainee.class, traineeId);
			System.out.println(trainee);
			manager.remove(trainee);
			
			manager.getTransaction().commit();		
			return true;
		} catch (RollbackException e) {
			
			throw new TraineeException("Trainee deletion failure !!!"+e);
		}
	}

	@Override
	public boolean updateTraineeDetails(Trainee trainee)
			throws TraineeException {
		EntityManager manager = factory.createEntityManager();
		try {
			manager.getTransaction().begin();
			
			manager.merge(trainee);
						
			manager.getTransaction().commit();		
			return true;
		} catch (RollbackException e) {
			
			throw new TraineeException("Trainee updation failure !!!"+e);
		}
		//return false;
	}
	
	

}