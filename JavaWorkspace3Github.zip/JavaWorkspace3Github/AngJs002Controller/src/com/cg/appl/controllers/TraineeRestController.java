package com.cg.appl.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;

//			http://localhost:8085/AngJs002Controller
@RestController
public class TraineeRestController {
		
		private TraineeServices service;

		public void setService(TraineeServices service) {
			this.service = service;
		}
		
		@RequestMapping(value="/trainees.do", method=RequestMethod.GET, headers="Accept=application/json")
																																				//MIME type
		public List<Trainee> getTraineeList() throws TraineeException
		{
			return service.getAllTrainee();
		}
}
