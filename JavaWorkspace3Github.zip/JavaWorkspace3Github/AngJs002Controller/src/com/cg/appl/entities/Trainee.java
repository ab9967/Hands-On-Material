package com.cg.appl.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.persistence.Column;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="trainee")
@Table(name="TRAINEE")
@SequenceGenerator(name="trainee_generate", sequenceName="TRAINEE_SEQ", allocationSize=1, initialValue=1010)
public class Trainee
{
	private int traineeId;
	private String traineeName;
	private String traineeDomain;
	private String traineeLocation;
	private String email;
	public Trainee() {
		super();
	}
	@Id
	@Column(name="traineeID")
	@GeneratedValue(generator="trainee_generate", strategy=GenerationType.SEQUENCE)
	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	@NotEmpty(message="Name required")
	//@Size(min=1,max=14,message="Name must be less than 15 characters !!!")
	@Column(name="traineeName")
	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	@Column(name="traineeDomain")
	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	@Column(name="traineeLocation")
	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	@Transient	//to ignore it for interacting with database
	@Email(message="Invalid Email Format !!!")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}

	
	
	
}
