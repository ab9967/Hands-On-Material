var traineeModule = angular.module("traineeModule", [])

var billController = traineeModule.controller("traineesController",

// constructor for controller traineeController
function($scope) // $scope is like model
{
	$scope.trainees = [ {
		'traineeId' : '104841',
		'traineeName' : 'ABC',
		'domain' : 'java',
		'location' : 'Mumbai'
	}, {
		'traineeId' : '104999',
		'traineeName' : 'DEF',
		'domain' : 'DotNet',
		'location' : 'Pune'
	}, {
		'traineeId' : '104777',
		'traineeName' : 'XYZ',
		'domain' : 'Python',
		'location' : 'Banglore'
	} ]; // end of object array
	
	
}// end of default function
);// end of controller

traineeModule.controller("traineeController",
	function($scope)
	{
		$scope.trainee = {
				'traineeName' : '',
				'domain' : '',
				'location' : ''
		};
		
		$scope.domains=[
		                'Java','DotNet','Scala','Python'
		                ];
		
		$scope.locations=[
		                  'Mumbai','Pune','Banglore','Chennai','Delhi'
		                  ];
	}
);
