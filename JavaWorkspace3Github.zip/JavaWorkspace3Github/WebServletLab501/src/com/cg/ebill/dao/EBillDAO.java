package com.cg.ebill.dao;

import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.UserException;

public interface EBillDAO {

	BillDTO calcEBill(BillDTO eBill, ConsumerDTO consumer);
	
	boolean storeToDB(BillDTO eBill);
	
	User userAuthentication(String userName) throws UserException;
	
	ConsumerDTO getConsumer(long consumerNo);
}
