package com.cg.appl.daos;

import com.cg.appl.util.DbUtil;


public class EntityDao
{
		private DbUtil dbUtil;
		//obj will be generatd by spring
		
		public EntityDao()
		{
			System.out.println("In EntityDao() constructor");
		}

		
		public void setDbUtil2(DbUtil dbUtil) {
			System.out.println("In setDbUtil()");
			this.dbUtil = dbUtil;
		}
		
		public void getConnection()
		{
			System.out.println("In getConnection() of Dao");
			dbUtil.getConnection();
		}
}