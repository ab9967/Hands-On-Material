package com.cg.appl.util;

import java.sql.Connection;

public class JndiUtilImpl implements DbUtil {

	public JndiUtilImpl()
	{
		System.out.println("In JndiUtil() constructor");
	}
	
	@Override
	public Connection getConnection() {
		System.out.println("In getConnection() of JNDIUtil");
		return null;
	}

}
