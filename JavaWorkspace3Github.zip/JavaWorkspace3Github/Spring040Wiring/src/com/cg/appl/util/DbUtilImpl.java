package com.cg.appl.util;

import java.sql.Connection;

public class DbUtilImpl implements DbUtil
{

	public DbUtilImpl() {
		super();
		System.out.println("In DbUtil() Constructor");
	}

	@Override
	public Connection getConnection() {
		System.out.println("In getConnection() method");
		return null;
	}
		
}
