package com.igate.intro;
public interface CurrencyConverter {

	public double dollarsToRupees(double dollars);
	
}