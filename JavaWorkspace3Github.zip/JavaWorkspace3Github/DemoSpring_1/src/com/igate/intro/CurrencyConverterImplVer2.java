package com.igate.intro;

public class CurrencyConverterImplVer2 extends CurrencyConverterImpl
{
	
	@Override
	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRupees() from Version 2");		
		return dollars * super.getExchangeRate();
	}
}
