package com.cg.appl.commons;

public class CompanyDetails
{
	private String companyName;
	private String companyMotto;
	private int niftyRank;
	private Address addr;
	
	
	public CompanyDetails() {
		super();
		
	}
		
	public CompanyDetails(String companyName, String companyMotto, int niftyRank) {
		super();
		this.companyName = companyName;
		this.companyMotto = companyMotto;
		this.niftyRank = niftyRank;
	}
	
	public String getCompanyName() {	//companyName = property name
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyMotto() {	//companyMotto = property name
		return companyMotto;
	}
	public void setCompanyMotto(String companyMotto) {
		this.companyMotto = companyMotto;
	}
	public int getNiftyRank() {		//niftyRank = property name
		return niftyRank;
	}
	public void setNiftyRank(int niftyRank) {
		this.niftyRank = niftyRank;
	}	

	//injection of other bean
	public Address getAddr() {		//addr = property name
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}	
	
	@Override
	public String toString() {
		return "CompanyDetails [companyName=" + companyName + ", companyMotto="
				+ companyMotto + ", niftyRank=" + niftyRank + ", address	=" + addr+ "]";	//toString of address will be called 
	}

}