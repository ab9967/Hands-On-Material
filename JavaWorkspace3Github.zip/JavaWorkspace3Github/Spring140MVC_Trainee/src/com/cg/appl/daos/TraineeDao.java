package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

public interface TraineeDao
{
		Trainee getTraineeDetails(int traineeId) throws TraineeException;
		
		List<Trainee>	getAllTrainee() throws TraineeException;
}
