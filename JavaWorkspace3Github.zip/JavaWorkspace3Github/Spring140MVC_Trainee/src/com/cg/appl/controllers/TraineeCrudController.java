package com.cg.appl.controllers;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;


//htttp://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class TraineeCrudController
{
	private TraineeServices services;
	
	@Resource(name="TraineeService") //service injection in controller
	public void setTraineeServices(TraineeServices services)
	{
		this.services  = services;
	}
	
		//give login .jsp
		@RequestMapping("/enterTraineeNo.do")
		public ModelAndView enterTraineeNo()
		{
			ModelAndView model = new ModelAndView("enterTraineeNo");
			return model;
		}
		
		//
		@RequestMapping("/getTraineeDetails.do") 	//here input parameter must be mapped to textfields in login.jsp file form
		public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo)
		{
			System.out.println("Trainee No : "+traineeNo);
			
			Trainee trainee;
			ModelAndView model = null;
			try {
				trainee = services.getTraineeDetails(traineeNo);
				
				model = new ModelAndView("traineeDetails");
				model.addObject("traineeDetails",trainee);
				
			} catch (TraineeException e) {				
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());
			}			
			return model;
		}
		
		@RequestMapping("/listAllTrainee.do")
		public ModelAndView listAllTrainees()
		{
			
			ModelAndView model = null;
			try 
			{				
				List<Trainee> tList = services.getAllTrainee();
				model = new ModelAndView("listAllTrainees");
				model.addObject("trainees", tList);
			}
			catch (TraineeException e)
			{
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());				
			}			 
			return model;
		}
}
