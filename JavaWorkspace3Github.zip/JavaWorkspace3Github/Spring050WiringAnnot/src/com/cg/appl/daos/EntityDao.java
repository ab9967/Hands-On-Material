package com.cg.appl.daos;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cg.appl.util.DbUtil;

@Repository("entityDao")
public class EntityDao
{
		private DbUtil dbUtil;
		//obj will be generatd by spring
		
		public EntityDao()
		{
			System.out.println("In EntityDao() constructor");
		}

		/*@Autowired
		@Qualifier("dbUtil1")*/
		@Resource(name="dbUtil2")
		public void setDbUtil(DbUtil dbUtil) {
			System.out.println("In setDbUtil() in dao");
			this.dbUtil = dbUtil;
		}
		
		public void getConnection()
		{
			System.out.println("In getConnection() of Dao");
			dbUtil.getConnection();
		}
}