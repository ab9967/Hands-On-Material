package com.cg.appl.contrallers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


//htttp://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class LoginController
{
		//give login .jsp
		@RequestMapping("/login.do")
		public ModelAndView showLoginPage()
		{
			ModelAndView model = new ModelAndView("login");
			return model;
		}
		
//		authentication
	
//		do authentication
/*		
 * 	@RequestMapping("/authenticate.do")
		public ModelAndView authenticate(HttpServletRequest request, HttpServletResponse response)
		{
			System.out.println(request.getParameter("userName"));
			System.out.println(request.getParameter("password"));
			
			ModelAndView model = new ModelAndView("success");
			return model;
		}
*/
		@RequestMapping("/authenticate.do") 	//here input parameter must be mapped to textfields in login.jsp file form
		public ModelAndView authenticate(@RequestParam String userName, @RequestParam String password)
		{
			System.out.println(userName);
			System.out.println(password);
			
			ModelAndView model = new ModelAndView();
			
			if(userName.equals("asd")&&password.equals("qwe"))
			{
				model.setViewName("success");
				model.addObject("userName", userName);
			}
			else
			{
				model.addObject("errMsg", "Login Failed please Re-Enter");
				model.setViewName("login");
			}
			return model;
		}
		
	//	show main menu or show login page again
}
