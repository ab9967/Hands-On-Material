package com.cg.appl.commons;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;


public class CompanyDetails
{
	private String companyName;
	private String companyMotto;
	private int niftyRank;
	private List<String>	directors;
	private Set<String> branches;
	private Map<String, String> branchAddr;//key values are string values
	private Properties ipAddresses;//key values are of object type
	private Address addr;
	
	
/*	public CompanyDetails(int niftyRank) {
		System.out.println("in *niftyRank* param Constructor of company Details");
		this.niftyRank = niftyRank;
	}
	
	public CompanyDetails(String companyMotto) {
		System.out.println("in *companyMotto* param Constructor of company Details");
		this.companyMotto = companyMotto;
	}*/
	
	public CompanyDetails(int niftyRank,	String companyMotto, Address address) {
		System.out.println("in *companyMotto**niftyRank* param Constructor of company Details");
		this.companyMotto = companyMotto;
		this.niftyRank = niftyRank;
		this.addr = address;
	}
	
	public String getCompanyName() {	//companyName = property name
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyMotto() {	//companyMotto = property name
		return companyMotto;
	}
	public void setCompanyMotto(String companyMotto) {
		this.companyMotto = companyMotto;
	}
	public int getNiftyRank() {		//niftyRank = property name
		return niftyRank;
	}
	public void setNiftyRank(int niftyRank) {
		this.niftyRank = niftyRank;
	}	

	//injection of other bean
	public Address getAddr() {		//addr = property name
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}	
	
	public List<String> getDirectors() {
		return directors;
	}

	public void setDirectors(List<String> directors) {
		this.directors = directors;
	}

	public Set<String> getBranches() {
		return branches;
	}

	public void setBranches(Set<String> branches) {
		this.branches = branches;
	}
	
	public Map<String, String> getBranchAddr() {
		return branchAddr;
	}

	public void setBranchAddr(Map<String, String> branchAddr) {
		this.branchAddr = branchAddr;
	}

	public Properties getIpAddresses() {
		return ipAddresses;
	}

	public void setIpAddresses(Properties ipAddresses) {
		this.ipAddresses = ipAddresses;
	}
	
	@Override
	public String toString() {
		return "CompanyDetails [companyName=" + companyName + ", companyMotto="
				+ companyMotto + ", niftyRank=" + niftyRank + ", \ndirectors="
				+ directors + ", \nbranches=" + branches + ", \nbranchAddr="
				+ branchAddr + ", \naddr=" + addr +"\n ipAddresses = "+ipAddresses+ "]";
	}
}