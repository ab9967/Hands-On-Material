create table trainee
(
	traineeID number(4) PRIMARY KEY,
	traineeName varchar2(15),
	traineeDomain varchar2(10),
	traineeLocation varchar2(10)
);