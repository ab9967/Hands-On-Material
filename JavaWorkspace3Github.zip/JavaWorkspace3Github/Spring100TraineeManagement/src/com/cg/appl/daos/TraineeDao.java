package com.cg.appl.daos;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

public interface TraineeDao
{
		Trainee getTraineeDetails(int traineeId) throws TraineeException;
}
