package com.cg.appl.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name="dept")
@Table(name="DEPT")
public class Dept
{
	private int deptId;
	private String deptNm;
	private String location;
	
	private List<Emp> Emps;
	
	@Id
	@Column(name="DEPTNO")
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	@Column(name="DNAME")
	public String getDeptNm() {
		return deptNm;
	}
	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}
	@Column(name="LOC")
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	@OneToMany(mappedBy="dept")//name of ownership property
	public List<Emp> getEmps() {
		return Emps;
	}
	public void setEmps(List<Emp> emps) {
		Emps = emps;
	}
	
	@Override
	public String toString() {
		return "Dept [deptId=" + deptId + ", deptNm=" + deptNm + ", location="
				+ location +"]";
	}	
	
}
