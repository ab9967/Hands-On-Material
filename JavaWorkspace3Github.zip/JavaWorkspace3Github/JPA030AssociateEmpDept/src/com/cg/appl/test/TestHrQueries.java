package com.cg.appl.test;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.services.HrService;
import com.cg.appl.services.HrServiceImpl;

public class TestHrQueries {

	public static void main(String[] args) {
		try {
			HrService services = new HrServiceImpl();
			
			/*List<Emp> empList = services.getEmpsOnSal(2000, 5000);
			
			//empList.forEach(System:);
			System.out.println("Named Query 1 Result : ");
			for(Emp index:empList)
				System.out.println(index);
			
			empList.clear();
			System.out.println("Named Query 2 Result : ");
			empList = services.getEmpList();
			
			for(Emp index:empList)
				System.out.println(index);
			*/
			/*Emp emp = new Emp();
			emp.setEmpNm("Steve");
			emp.setEmpSal(5000f);
			
			Emp emp1 = services.admitNewEmp(emp);
			System.out.println("After insertion");
			System.out.println(emp1);*/
			
			/*System.out.println("Employee's with Commision : ");
			
			List<Emp> empList = services.getEmpsForCommision();
			for(Emp index:empList)
			{
				System.out.println(index);
			}*/
			
			/*Dept dept = services.getDeptDetails(20);
			System.out.println(dept);*/
			
			/*Emp emp = services.getEmpDetails(7788);
			
			Dept dept = services.getDeptDetails(emp.getDept().getDeptId());
			System.out.println(emp);
			System.out.println("Fetching dept using navigation !!!");
			System.out.println(dept);*/
			
			Dept dept = services.getDeptDetails(30);
			System.out.println(dept);//getting data from dept entity
			System.out.println("#################################################");
			for(Emp index:dept.getEmps())//getting data from emp entity which is mapped by dept entity
			{
				System.out.println(index);
			}
			
		} catch (HrException e) {
			
			e.printStackTrace();
		}
	}

}
