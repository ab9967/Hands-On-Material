package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public interface HrService
{
	Emp getEmpDetails(int empNo) throws HrException;
	
	List<Emp> getEmpList() throws HrException;
	
	//Emp admitNewEmp(Emp emp) throws EmpException;
	
	//boolean updateName(int empNo, String newName) throws EmpException;
	
	//boolean updateEmp(Emp emp) throws EmpException;
	
	//boolean delete(int empNo) throws EmpException;
	
	List<Emp> getEmpsOnSal(float from, float to) throws HrException;
	
	List<Emp> getEmpsForCommision() throws HrException;

	Dept getDeptDetails(int deptID) throws HrException;
}
