package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.HrDao;
import com.cg.appl.daos.HrDaoImpl;
import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public class HrServiceImpl implements HrService {

	private HrDao dao;
	
	
	
	public HrServiceImpl() throws HrException {
		super();
		dao = new HrDaoImpl();
	}

	@Override
	public Emp getEmpDetails(int empNo) throws HrException {
		
		return dao.getEmpDetailsSafe(empNo);
	}

	@Override
	public List<Emp> getEmpList() throws HrException {
		
		return dao.getEmpList();
	}

	/*@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		
		return dao.admitNewEmp(emp);
	}*/

	/*@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		
		return dao.updateName(empNo, newName);
	}*/

	/*@Override
	public boolean updateEmp(Emp emp) throws EmpException {
		
		return dao.updateEmp(emp);
	}*/

	/*@Override
	public boolean delete(int empNo) throws EmpException {
		
		return dao.delete(empNo);
	}*/

	@Override
	public List<Emp> getEmpsOnSal(float from, float to) throws HrException {
		
		return dao.getEmpsOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpsForCommision() throws HrException {
		
		return dao.getEmpsForCommision();
	}

	@Override
	public Dept getDeptDetails(int deptID) throws HrException {
		
		return dao.getDeptDetails(deptID);
	}

}
