package com.cg.ebill.dto;

//import java.io.Serializable;

public class User{
	
	//entities must implement serializable
	
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	
	private String userName, password, userFName;

	public User(String userName, String password, String userFullName) {
		super();
		this.userName = userName;
		this.password = password;
		this.userFName = userFullName;
	}

	public User() {
		// TODO Auto-generated constructor stub
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserFullName() {
		return userFName;
	}

	public void setUserFullName(String userFullName) {
		this.userFName = userFullName;
	}

	
	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password
				+ ", userFullName=" + userFName + "]";
	}

	
}
