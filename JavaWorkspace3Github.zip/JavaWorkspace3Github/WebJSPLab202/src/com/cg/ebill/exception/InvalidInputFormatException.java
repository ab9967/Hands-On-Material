package com.cg.ebill.exception;

public class InvalidInputFormatException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidInputFormatException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidInputFormatException(String arg0, Throwable arg1,
			boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidInputFormatException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidInputFormatException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidInputFormatException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}	
	
}
